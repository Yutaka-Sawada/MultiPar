﻿#define CLIENT_VERSION	0x1320		// クライアントのバージョン番号
