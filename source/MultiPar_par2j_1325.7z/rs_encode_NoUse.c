
static DWORD WINAPI thread_encode_chunk2(LPVOID lpParameter)
{
	unsigned char *s_buf, *p_buf, *work_buf;
	unsigned short *constant, factor2;
	volatile unsigned short *factor1;
	int i, j, th_id, part_start, part_num, src_start, src_num, max_num;
	int chunk_num, cover_from, cover_num;
	unsigned int unit_size, len, off, chunk_size;
	HANDLE hRun, hEnd;
	RS_TH *th;
#ifdef TIMER
unsigned int loop_count2a = 0, loop_count2b = 0;
unsigned int time_start2, time_encode2a = 0, time_encode2b = 0;
#endif

	th = (RS_TH *)lpParameter;
	constant = th->mat;
	p_buf = th->buf;
	unit_size = th->size;
	part_num = th->count;
	th_id = th->now;	// スレッド番号
	chunk_size = th->off;
	hRun = th->run;
	hEnd = th->end;
	//_mm_sfence();
	SetEvent(hEnd);	// 設定完了を通知する

	factor1 = constant + source_num;
	chunk_num = (unit_size + chunk_size - 1) / chunk_size;

	WaitForSingleObject(hRun, INFINITE);	// 計算開始の合図を待つ
	while (th->now < INT_MAX / 2){
#ifdef TIMER
time_start2 = GetTickCount();
#endif
		s_buf = th->buf;
		src_start = th->off;	// ソース・ブロック番号
		len = chunk_size;

		if (th->size == 0){	// ソース・ブロック読み込み中
			// パリティ・ブロックごとに掛け算して追加していく
			max_num = chunk_num * part_num;
			while ((j = InterlockedIncrement(&(th->now))) < max_num){	// j = ++th_now
				off = j / part_num;	// chunk の番号
				j = j % part_num;	// parity の番号
				off *= chunk_size;
				if (off + len > unit_size)
					len = unit_size - off;	// 最後の chunk だけサイズが異なるかも
				if (src_start == 0)	// 最初のブロックを計算する際に
					memset(p_buf + ((size_t)unit_size * j + off), 0, len);	// ブロックを 0で埋める
				galois_align_multiply(s_buf + off, p_buf + ((size_t)unit_size * j + off), len, factor1[j]);
#ifdef TIMER
loop_count2a++;
#endif
			}
#ifdef TIMER
time_encode2a += GetTickCount() - time_start2;
#endif
		} else {
			// スレッドごとに作成するパリティ・ブロックの chunk を変える
			part_start = (th->count) >> 16;
			src_num = (th->count) & 0x0000FFFF;
			cover_num = (th->size) >> 16;
			cover_from = (th->size) & 0x0000FFFF;
			max_num = chunk_num * cover_num;
			while ((j = InterlockedIncrement(&(th->now))) < max_num){	// j = ++th_now
				off = j / cover_num;	// chunk の番号
				j = j % cover_num;		// parity の番号
				off *= chunk_size;		// chunk の位置
				if (off + len > unit_size)
					len = unit_size - off;	// 最後の chunk だけサイズが異なるかも
				work_buf = p_buf + (size_t)unit_size * (cover_from + j) + off;
				if (part_start != 0)
					memset(work_buf, 0, len);	// 最初の part_num 以降は 2nd encode だけなので 0で埋める

				// ソース・ブロックごとにパリティを追加していく
				for (i = 0; i < src_num; i++){
					factor2 = galois_power(constant[src_start + i], first_num + part_start + cover_from + j);	// factor は定数行列の乗数になる
					galois_align_multiply(s_buf + ((size_t)unit_size * i + off), work_buf, len, factor2);
				}

#ifdef TIMER
loop_count2b += src_num;
#endif
			}
#ifdef TIMER
time_encode2b += GetTickCount() - time_start2;
#endif
		}
		//_mm_sfence();	// メモリーへの書き込みを完了する
		SetEvent(hEnd);	// 計算終了を通知する
		WaitForSingleObject(hRun, INFINITE);	// 計算開始の合図を待つ
	}
#ifdef TIMER
loop_count2a /= (unit_size + chunk_size - 1) / chunk_size;	// chunk数で割ってブロック数にする
loop_count2b /= (unit_size + chunk_size - 1) / chunk_size;
printf("sub-thread[%d] : total loop = %d\n", th_id, loop_count2a + loop_count2b);
if (time_encode2a > 0){
	i = (int)((__int64)loop_count2a * unit_size * 125 / ((__int64)time_encode2a * 131072));
} else {
	i = 0;
}
if (loop_count2a > 0)
	printf(" 1st encode %d.%03d sec, %d loop, %d MB/s\n", time_encode2a / 1000, time_encode2a % 1000, loop_count2a, i);
if (time_encode2b > 0){
	i = (int)((__int64)loop_count2b * unit_size * 125 / ((__int64)time_encode2b * 131072));
} else {
	i = 0;
}
printf(" 2nd encode %d.%03d sec, %d loop, %d MB/s\n", time_encode2b / 1000, time_encode2b % 1000, loop_count2b, i);
#endif

	// 終了処理
	CloseHandle(hRun);
	CloseHandle(hEnd);
	return 0;
}

int encode_method6(	// 全てのブロックを断片的に保持する場合 (chunkごと)
	wchar_t *file_path,
	unsigned char *header_buf,	// Recovery Slice packet のパケット・ヘッダー
	HANDLE *rcv_hFile,			// リカバリ・ファイルのハンドル
	file_ctx_c *files,			// ソース・ファイルの情報
	source_ctx_c *s_blk,		// ソース・ブロックの情報
	parity_ctx_c *p_blk,		// パリティ・ブロックの情報
	unsigned short *constant)	// 複数ブロック分の領域を確保しておく？
{
	unsigned char *buf = NULL, *p_buf, *work_buf, *hash;
	unsigned short *factor1;
	int err = 0, i, j, last_file;
	int src_num, chunk_num;
	unsigned int io_size, unit_size, len, block_off;
	unsigned int time_last, prog_write;
	__int64 file_off, prog_num = 0, prog_base;
	HANDLE hFile = NULL;
	HANDLE hSub[MAX_CPU], hRun[MAX_CPU], hEnd[MAX_CPU];
	RS_TH th[1];
	PHMD5 md_ctx, *md_ptr = NULL;

	memset(hSub, 0, sizeof(HANDLE) * MAX_CPU);
	factor1 = constant + source_num;

	// 作業バッファーを確保する
	// part_num を使わず、全てのブロックを保持する所がencode_method2と異なることに注意！
	io_size = get_io_size(source_num + parity_num, NULL, 1, sse_unit);
	//io_size = (((io_size + 1) / 2 + HASH_SIZE + (sse_unit - 1)) & ~(sse_unit - 1)) - HASH_SIZE;	// 2分割の実験用
	//io_size = (((io_size + 2) / 3 + HASH_SIZE + (sse_unit - 1)) & ~(sse_unit - 1)) - HASH_SIZE;	// 3分割の実験用
	unit_size = io_size + HASH_SIZE;	// チェックサムの分だけ増やす
	file_off = (source_num + parity_num) * (size_t)unit_size + HASH_SIZE;
	buf = _aligned_malloc((size_t)file_off, sse_unit);
	if (buf == NULL){
		printf("malloc, %I64d\n", file_off);
		err = 1;
		goto error_end;
	}
	p_buf = buf + (size_t)unit_size * source_num;	// パリティ・ブロックを記録する領域
	hash = p_buf + (size_t)unit_size * parity_num;
	prog_base = (block_size + io_size - 1) / io_size;
	prog_write = source_num >> 5;	// 計算で 97%、書き込みで 3% ぐらい
	if (prog_write == 0)
		prog_write = 1;
	prog_base *= (__int64)(source_num + prog_write) * parity_num;	// 全体の断片の個数
	len = try_cache_blocking(unit_size);
	//len = ((len + 2) / 3 + (sse_unit - 1)) & ~(sse_unit - 1);	// 3分割の実験用
	chunk_num = (unit_size + len - 1) / len;
#ifdef TIMER
	printf("\n read all source blocks, and keep all parity blocks (chunk)\n");
	printf("buffer size = %I64d MB, io_size = %d, split = %d\n", file_off >> 20, io_size, (block_size + io_size - 1) / io_size);
	printf("cache: limit size = %d, chunk_size = %d, split = %d\n", cpu_flag & 0x7FFF8000, len, chunk_num);
	printf("prog_base = %I64d, unit_size = %d\n", prog_base, unit_size);
#endif

	if (io_size < block_size){	// スライスが分割される場合だけ、途中までのハッシュ値を保持する
		block_off = sizeof(PHMD5) * parity_num;
		md_ptr = malloc(block_off);
		if (md_ptr == NULL){
			printf("malloc, %d\n", block_off);
			err = 1;
			goto error_end;
		}
		for (i = 0; i < parity_num; i++){
			Phmd5Begin(&(md_ptr[i]));
			j = first_num + i;	// 最初の番号の分だけ足す
			memcpy(header_buf + 64, &j, 4);	// Recovery Slice の番号を書き込む
			Phmd5Process(&(md_ptr[i]), header_buf + 32, 36);
		}
	}

	// マルチ・スレッドの準備をする
	th->mat = constant;
	th->buf = p_buf;
	th->size = unit_size;
	th->count = parity_num;
	th->off = len;	// キャッシュの最適化を試みる
	for (j = 0; j < cpu_num; j++){	// サブ・スレッドごとに
		hRun[j] = CreateEvent(NULL, FALSE, FALSE, NULL);	// Auto Reset にする
		if (hRun[j] == NULL){
			print_win32_err();
			printf("error, sub-thread\n");
			err = 1;
			goto error_end;
		}
		hEnd[j] = CreateEvent(NULL, TRUE, FALSE, NULL);
		if (hEnd[j] == NULL){
			print_win32_err();
			CloseHandle(hRun[j]);
			printf("error, sub-thread\n");
			err = 1;
			goto error_end;
		}
		// サブ・スレッドを起動する
		th->run = hRun[j];
		th->end = hEnd[j];
		th->now = j;	// スレッド番号
		//_mm_sfence();	// メモリーへの書き込みを完了してからスレッドを起動する
		hSub[j] = (HANDLE)_beginthreadex(NULL, STACK_SIZE, thread_encode_chunk, (LPVOID)th, 0, NULL);
		if (hSub[j] == NULL){
			print_win32_err();
			CloseHandle(hRun[j]);
			CloseHandle(hEnd[j]);
			printf("error, sub-thread\n");
			err = 1;
			goto error_end;
		}
		WaitForSingleObject(hEnd[j], INFINITE);	// 設定終了の合図を待つ (リセットしない)
	}
	// IO が延滞しないように、サブ・スレッド一つの優先度を下げる
	SetThreadPriority(hSub[0], THREAD_PRIORITY_BELOW_NORMAL);

	// ソース・ブロック断片を読み込んで、パリティ・ブロック断片を作成する
	time_last = GetTickCount();
	wcscpy(file_path, base_dir);
	block_off = 0;
	while (block_off < block_size){
		th->size = 0;	// 1st encode
		th->off = -1;	// まだ計算して無い印

		// ソース・ブロックを読み込む
#ifdef TIMER
read_count = 0;
skip_count = 0;
time_start = GetTickCount();
#endif
		last_file = -1;
		for (i = 0; i < source_num; i++){
			if (s_blk[i].file != last_file){	// 別のファイルなら開く
				last_file = s_blk[i].file;
				if (hFile){
					CloseHandle(hFile);	// 前のファイルを閉じる
					hFile = NULL;
				}
				wcscpy(file_path + base_len, list_buf + files[last_file].name);
				hFile = CreateFile(file_path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
				if (hFile == INVALID_HANDLE_VALUE){
					print_win32_err();
					hFile = NULL;
					printf_cp("cannot open file, %s\n", list_buf + files[last_file].name);
					err = 1;
					goto error_end;
				}
				file_off = block_off;
			} else {	// 同じファイルならブロック・サイズ分ずらす
				file_off += block_size;
			}
			if (s_blk[i].size > block_off){	// バッファーにソース・ファイルの内容を読み込む
				len = s_blk[i].size - block_off;
				if (len > io_size)
					len = io_size;
				if (file_read_data(hFile, file_off, buf + (size_t)unit_size * i, len)){
					printf("file_read_data, input slice %d\n", i);
					err = 1;
					goto error_end;
				}
				if (len < io_size)
					memset(buf + ((size_t)unit_size * i + len), 0, io_size - len);
				// ソース・ブロックのチェックサムを計算する
				if (block_off == 0)
					s_blk[i].crc = 0xFFFFFFFF;
				s_blk[i].crc = crc_update(s_blk[i].crc, buf + (size_t)unit_size * i, len);	// without pad
				checksum16_altmap(buf + (size_t)unit_size * i, buf + ((size_t)unit_size * i + io_size), io_size);
#ifdef TIMER
read_count++;
#endif

				if (i + 1 < source_num){	// 最後のブロック以外なら
					// サブ・スレッドの動作状況を調べる
					j = WaitForMultipleObjects((cpu_num + 1) / 2, hEnd, TRUE, 0);
					if ((j != WAIT_TIMEOUT) && (j != WAIT_FAILED)){	// 計算中でないなら
						// 経過表示
						prog_num += parity_num;
						if (GetTickCount() - time_last >= UPDATE_TIME){
							if (print_progress((int)((prog_num * 1000) / prog_base))){
								err = 2;
								goto error_end;
							}
							time_last = GetTickCount();
						}
						// 計算終了したブロックの次から計算を開始する
						th->off += 1;
						if (th->off > 0){	// バッファーに読み込んだ時だけ計算する
							while (s_blk[th->off].size <= block_off){
								prog_num += parity_num;
								th->off += 1;
#ifdef TIMER
skip_count++;
#endif
							}
						}
						th->buf = buf + (size_t)unit_size * th->off;
						for (j = 0; j < parity_num; j++)
							factor1[j] = galois_power(constant[th->off], first_num + j);	// factor は定数行列の乗数になる
						th->now = -1;	// 初期値 - 1
						//_mm_sfence();
						for (j = 0; j < (cpu_num + 1) / 2; j++){
							ResetEvent(hEnd[j]);	// リセットしておく
							SetEvent(hRun[j]);	// サブ・スレッドに計算を開始させる
						}
					}
				}
			} else {
				memset(buf + (size_t)unit_size * i, 0, unit_size);
			}
		}
		// 最後のソース・ファイルを閉じる
		CloseHandle(hFile);
		hFile = NULL;
#ifdef TIMER
time_read += GetTickCount() - time_start;
#endif

		WaitForMultipleObjects((cpu_num + 1) / 2, hEnd, TRUE, INFINITE);	// サブ・スレッドの計算終了の合図を待つ
		th->size = 0x0000FFFF;	// 2nd encode
		th->off += 1;	// 計算を開始するソース・ブロックの番号
		if (th->off > 0){
			while (s_blk[th->off].size <= block_off){	// 計算不要なソース・ブロックはとばす
				prog_num += parity_num;
				th->off += 1;
#ifdef TIMER
skip_count++;
#endif
			}
		} else {	// エラーや実験時以外は th->off は 0 にならない
			memset(p_buf, 0, (size_t)unit_size * parity_num);
		}
#ifdef TIMER
		j = (th->off * 1000) / source_num;
		printf("partial encode = %d / %d (%d.%d%%), read = %d, skip = %d\n", th->off, source_num, j / 10, j % 10, read_count, skip_count);
#endif

		// リカバリ・ファイルに書き込むサイズ
		if (block_size - block_off < io_size){
			len = block_size - block_off;
		} else {
			len = io_size;
		}

		// スレッドごとにパリティ・ブロックを計算する
		src_num = source_num - th->off;	// 一度に処理する量 (src_num > 0)
		th->buf = buf + (size_t)unit_size * (th->off);
		th->count = src_num;
		th->now = -1;	// 初期値 - 1
		//_mm_sfence();
		for (j = 0; j < cpu_num; j++){
			ResetEvent(hEnd[j]);	// リセットしておく
			SetEvent(hRun[j]);	// サブ・スレッドに計算を開始させる
		}

		// サブ・スレッドの計算終了の合図を UPDATE_TIME だけ待ちながら、経過表示する
		while (WaitForMultipleObjects(cpu_num, hEnd, TRUE, UPDATE_TIME) == WAIT_TIMEOUT){
			// th-now が最高値なので、計算が終わってるのは th-now - cpu_num 個となる
			j = th->now - cpu_num;
			if (j < 0)
				j = 0;
			j /= chunk_num;	// chunk数で割ってブロック数にする
			// 経過表示（UPDATE_TIME 時間待った場合なので、必ず経過してるはず）
			if (print_progress((int)(((prog_num + src_num * j) * 1000) / prog_base))){
				err = 2;
				goto error_end;
			}
			time_last = GetTickCount();
		}
		prog_num += src_num * parity_num;

#ifdef TIMER
time_start = GetTickCount();
#endif
		// パリティ・ブロックを書き込む
		work_buf = p_buf;
		for (i = 0; i < parity_num; i++){
			// パリティ・ブロックのチェックサムを検証する
			checksum16_return(work_buf, hash, io_size);
			if (memcmp(work_buf + io_size, hash, HASH_SIZE) != 0){
				printf("checksum mismatch, recovery slice %d\n", i);
				err = 1;
				goto error_end;
			}
			// ハッシュ値を計算して、リカバリ・ファイルに書き込む
			if (io_size >= block_size){	// 1回で書き込みが終わるなら
				Phmd5Begin(&md_ctx);
				j = first_num + i;	// 最初の番号の分だけ足す
				memcpy(header_buf + 64, &j, 4);	// Recovery Slice の番号を書き込む
				Phmd5Process(&md_ctx, header_buf + 32, 36);
				Phmd5Process(&md_ctx, work_buf, len);
				Phmd5End(&md_ctx);
				memcpy(header_buf + 16, md_ctx.hash, 16);
				// ヘッダーを書き込む
				if (file_write_data(rcv_hFile[p_blk[i].file], p_blk[i].off + block_off - 68, header_buf, 68)){
					printf("file_write_data, recovery slice %d\n", i);
					err = 1;
					goto error_end;
				}
			} else {
				Phmd5Process(&(md_ptr[i]), work_buf, len);
			}
			//printf("%d, buf = %p, size = %u, off = %I64d\n", i, work_buf, len, p_blk[i].off + block_off);
			if (file_write_data(rcv_hFile[p_blk[i].file], p_blk[i].off + block_off, work_buf, len)){
				printf("file_write_data, recovery slice %d\n", i);
				err = 1;
				goto error_end;
			}
			work_buf += unit_size;

			// 経過表示
			prog_num += prog_write;
			if (GetTickCount() - time_last >= UPDATE_TIME){
				if (print_progress((int)((prog_num * 1000) / prog_base))){
					err = 2;
					goto error_end;
				}
				time_last = GetTickCount();
			}
		}
#ifdef TIMER
time_write += GetTickCount() - time_start;
#endif

		block_off += io_size;
	}
	print_progress_done();	// 改行して行の先頭に戻しておく
	//printf("prog_num = %I64d / %I64d\n", prog_num, prog_base);

	// ファイルごとにブロックの CRC-32 を検証する
	memset(buf, 0, io_size);
	j = 0;
	while (j < source_num){
		last_file = s_blk[j].file;
		src_num = (int)((files[last_file].size + (__int64)block_size - 1) / block_size);
		i = j + src_num - 1;	// 末尾ブロックの番号
		if (s_blk[i].size < block_size){	// 残りを 0 でパディングする
			len = block_size - s_blk[i].size;
			while (len > io_size){
				len -= io_size;
				s_blk[i].crc = crc_update(s_blk[i].crc, buf, io_size);
			}
			s_blk[i].crc = crc_update(s_blk[i].crc, buf, len);
		}
		memset(hash, 0, 16);
		for (i = 0; i < src_num; i++)	// XOR して 16バイトに減らす
			((unsigned int *)hash)[i & 3] ^= s_blk[j + i].crc ^ 0xFFFFFFFF;
		if (memcmp(files[last_file].hash, hash, 16) != 0){
			printf("checksum mismatch, input file %d\n", last_file);
			err = 1;
			goto error_end;
		}
		j += src_num;
	}

	//printf("io_size = %d, block_size = %d\n", io_size, block_size);
	if (io_size < block_size){	// 1回で書き込みが終わらなかったなら
		if (GetTickCount() - time_last >= UPDATE_TIME){	// キャンセルを受け付ける
			if (cancel_progress()){
				err = 2;
				goto error_end;
			}
		}

#ifdef TIMER
time_start = GetTickCount();
#endif
		// 最後に Recovery Slice packet のヘッダーを書き込む
		for (i = 0; i < parity_num; i++){
			Phmd5End(&(md_ptr[i]));
			memcpy(header_buf + 16, md_ptr[i].hash, 16);
			j = first_num + i;	// 最初のパリティ・ブロック番号の分だけ足す
			memcpy(header_buf + 64, &j, 4);	// Recovery Slice の番号を書き込む
			// リカバリ・ファイルに書き込む
			if (file_write_data(rcv_hFile[p_blk[i].file], p_blk[i].off - 68, header_buf, 68)){	// ヘッダーのサイズ分だけずらす
				printf("file_write_data, packet header\n");
				err = 1;
				goto error_end;
			}
		}
#ifdef TIMER
time_write += GetTickCount() - time_start;
#endif
	}

#ifdef TIMER
printf("read   %d.%03d sec\n", time_read / 1000, time_read % 1000);
printf("write  %d.%03d sec\n", time_write / 1000, time_write % 1000);
#endif

error_end:
	InterlockedExchange(&(th->now), INT_MAX / 2);	// サブ・スレッドの計算を中断する
	for (j = 0; j < cpu_num; j++){
		if (hSub[j]){	// サブ・スレッドを終了させる
			SetEvent(hRun[j]);
			WaitForSingleObject(hSub[j], INFINITE);
			CloseHandle(hSub[j]);
		}
	}
	if (md_ptr)
		free(md_ptr);
	if (hFile)
		CloseHandle(hFile);
	if (buf)
		_aligned_free(buf);
	return err;
}

// cover_num ごとに計算して書き込むバージョン
int encode_method8c(	// ソース・データを全て読み込む場合 (chunkごと)
	wchar_t *file_path,
	unsigned char *header_buf,	// Recovery Slice packet のパケット・ヘッダー
	HANDLE *rcv_hFile,			// リカバリ・ファイルのハンドル
	file_ctx_c *files,			// ソース・ファイルの情報
	source_ctx_c *s_blk,		// ソース・ブロックの情報
	parity_ctx_c *p_blk,		// パリティ・ブロックの情報
	unsigned short *constant)	// 複数ブロック分の領域を確保しておく？
{
	unsigned char *buf = NULL, *p_buf, *work_buf, *hash;
	unsigned short *factor1;
	int err = 0, i, j, last_file, part_start, part_num;
	int src_num, cover_from, cover_num;
	unsigned int io_size, unit_size, len, block_off;
	unsigned int time_last;
	__int64 file_off, prog_num = 0, prog_base;
	HANDLE hFile = NULL;
	HANDLE hSub[MAX_CPU], hRun[MAX_CPU], hEnd[MAX_CPU];
	RS_TH th[1];
	PHMD5 md_ctx, *md_ptr = NULL;

	memset(hSub, 0, sizeof(HANDLE) * MAX_CPU);
	factor1 = constant + source_num;

	// 作業バッファーを確保する
	part_num = source_num >> PART_MAX_RATE;	// ソース・ブロック数に対する割合で最大量を決める
	part_num = ((part_num + cpu_num - 1) / cpu_num) * cpu_num;	// cpu_num の倍数にする
	if (part_num < cpu_num * PART_MIN_NUM)
		part_num = cpu_num * PART_MIN_NUM;	// ダブル・バッファリングしないけど、1st encode 用に確保しておく
	//part_num = cpu_num * 4;	// 確保量の実験用
	if (part_num > parity_num)
		part_num = parity_num;
	io_size = get_io_size(source_num, &part_num, 1, sse_unit);
	//io_size = (((io_size + 1) / 2 + HASH_SIZE + (sse_unit - 1)) & ~(sse_unit - 1)) - HASH_SIZE;	// 2分割の実験用
	//io_size = (((io_size + 2) / 3 + HASH_SIZE + (sse_unit - 1)) & ~(sse_unit - 1)) - HASH_SIZE;	// 3分割の実験用
	unit_size = io_size + HASH_SIZE;	// チェックサムの分だけ増やす
	file_off = (source_num + part_num) * (size_t)unit_size + HASH_SIZE;
	buf = _aligned_malloc((size_t)file_off, sse_unit);
	if (buf == NULL){
		printf("malloc, %I64d\n", file_off);
		err = 1;
		goto error_end;
	}
	p_buf = buf + (size_t)unit_size * source_num;	// パリティ・ブロックを記録する領域
	hash = p_buf + (size_t)unit_size * part_num;
	prog_base = (block_size + io_size - 1) / io_size;
	prog_base *= source_num * parity_num;	// 全体の断片の個数
	len = try_cache_blocking(unit_size);
	//len = ((len + 2) / 3 + (sse_unit - 1)) & ~(sse_unit - 1);	// 1/3の実験用
#ifdef TIMER
	printf("\n read all source blocks, and keep some parity blocks (chunk)\n");
	printf("buffer size = %I64d MB, io_size = %d, split = %d\n", file_off >> 20, io_size, (block_size + io_size - 1) / io_size);
	printf("cache: limit size = %d, chunk_size = %d, split = %d\n", cpu_flag & 0x7FFF8000, len, (unit_size + len - 1) / len);
	printf("prog_base = %I64d, unit_size = %d, part_num = %d\n", prog_base, unit_size, part_num);
#endif

	if (io_size < block_size){	// スライスが分割される場合だけ、途中までのハッシュ値を保持する
		block_off = sizeof(PHMD5) * parity_num;
		md_ptr = malloc(block_off);
		if (md_ptr == NULL){
			printf("malloc, %d\n", block_off);
			err = 1;
			goto error_end;
		}
		for (i = 0; i < parity_num; i++){
			Phmd5Begin(&(md_ptr[i]));
			j = first_num + i;	// 最初の番号の分だけ足す
			memcpy(header_buf + 64, &j, 4);	// Recovery Slice の番号を書き込む
			Phmd5Process(&(md_ptr[i]), header_buf + 32, 36);
		}
	}

	// マルチ・スレッドの準備をする
	th->mat = constant;
	th->buf = p_buf;
	th->size = unit_size;
	th->count = part_num;
	th->off = len;	// キャッシュの最適化を試みる
	for (j = 0; j < cpu_num; j++){	// サブ・スレッドごとに
		hRun[j] = CreateEvent(NULL, FALSE, FALSE, NULL);	// Auto Reset にする
		if (hRun[j] == NULL){
			print_win32_err();
			printf("error, sub-thread\n");
			err = 1;
			goto error_end;
		}
		hEnd[j] = CreateEvent(NULL, TRUE, FALSE, NULL);
		if (hEnd[j] == NULL){
			print_win32_err();
			CloseHandle(hRun[j]);
			printf("error, sub-thread\n");
			err = 1;
			goto error_end;
		}
		// サブ・スレッドを起動する
		th->run = hRun[j];
		th->end = hEnd[j];
		th->now = j;	// スレッド番号
		//_mm_sfence();	// メモリーへの書き込みを完了してからスレッドを起動する
		hSub[j] = (HANDLE)_beginthreadex(NULL, STACK_SIZE, thread_encode_chunk2, (LPVOID)th, 0, NULL);
		if (hSub[j] == NULL){
			print_win32_err();
			CloseHandle(hRun[j]);
			CloseHandle(hEnd[j]);
			printf("error, sub-thread\n");
			err = 1;
			goto error_end;
		}
		WaitForSingleObject(hEnd[j], INFINITE);	// 設定終了の合図を待つ (リセットしない)
	}
	// IO が延滞しないように、サブ・スレッド一つの優先度を下げる
	SetThreadPriority(hSub[0], THREAD_PRIORITY_BELOW_NORMAL);

	// ソース・ブロック断片を読み込んで、パリティ・ブロック断片を作成する
	time_last = GetTickCount();
	wcscpy(file_path, base_dir);
	block_off = 0;
	while (block_off < block_size){
		th->size = 0;	// 1st encode
		th->off = -1;	// まだ計算して無い印

		// ソース・ブロックを読み込む
#ifdef TIMER
read_count = 0;
skip_count = 0;
time_start = GetTickCount();
#endif
		last_file = -1;
		for (i = 0; i < source_num; i++){
			if (s_blk[i].file != last_file){	// 別のファイルなら開く
				last_file = s_blk[i].file;
				if (hFile){
					CloseHandle(hFile);	// 前のファイルを閉じる
					hFile = NULL;
				}
				wcscpy(file_path + base_len, list_buf + files[last_file].name);
				hFile = CreateFile(file_path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
				if (hFile == INVALID_HANDLE_VALUE){
					print_win32_err();
					hFile = NULL;
					printf_cp("cannot open file, %s\n", list_buf + files[last_file].name);
					err = 1;
					goto error_end;
				}
				file_off = block_off;
			} else {	// 同じファイルならブロック・サイズ分ずらす
				file_off += block_size;
			}
			if (s_blk[i].size > block_off){	// バッファーにソース・ファイルの内容を読み込む
				len = s_blk[i].size - block_off;
				if (len > io_size)
					len = io_size;
				if (file_read_data(hFile, file_off, buf + (size_t)unit_size * i, len)){
					printf("file_read_data, input slice %d\n", i);
					err = 1;
					goto error_end;
				}
				if (len < io_size)
					memset(buf + ((size_t)unit_size * i + len), 0, io_size - len);
				// ソース・ブロックのチェックサムを計算する
				if (block_off == 0)
					s_blk[i].crc = 0xFFFFFFFF;
				s_blk[i].crc = crc_update(s_blk[i].crc, buf + (size_t)unit_size * i, len);	// without pad
				checksum16_altmap(buf + (size_t)unit_size * i, buf + ((size_t)unit_size * i + io_size), io_size);
#ifdef TIMER
read_count++;
#endif

				if (i + 1 < source_num){	// 最後のブロック以外なら
					// サブ・スレッドの動作状況を調べる
					j = WaitForMultipleObjects((cpu_num + 1) / 2, hEnd, TRUE, 0);
					if ((j != WAIT_TIMEOUT) && (j != WAIT_FAILED)){	// 計算中でないなら
						// 経過表示
						prog_num += part_num;
						if (GetTickCount() - time_last >= UPDATE_TIME){
							if (print_progress((int)((prog_num * 1000) / prog_base))){
								err = 2;
								goto error_end;
							}
							time_last = GetTickCount();
						}
						// 計算終了したブロックの次から計算を開始する
						th->off += 1;
						if (th->off > 0){	// バッファーに読み込んだ時だけ計算する
							while (s_blk[th->off].size <= block_off){
								prog_num += part_num;
								th->off += 1;
#ifdef TIMER
skip_count++;
#endif
							}
						}
						th->buf = buf + (size_t)unit_size * th->off;
						for (j = 0; j < part_num; j++)
							factor1[j] = galois_power(constant[th->off], first_num + j);	// factor は定数行列の乗数になる
						th->now = -1;	// 初期値 - 1
						//_mm_sfence();
						for (j = 0; j < (cpu_num + 1) / 2; j++){
							ResetEvent(hEnd[j]);	// リセットしておく
							SetEvent(hRun[j]);	// サブ・スレッドに計算を開始させる
						}
					}
				}
			} else {
				memset(buf + (size_t)unit_size * i, 0, unit_size);
			}
		}
		// 最後のソース・ファイルを閉じる
		CloseHandle(hFile);
		hFile = NULL;
#ifdef TIMER
time_read += GetTickCount() - time_start;
#endif

		WaitForMultipleObjects((cpu_num + 1) / 2, hEnd, TRUE, INFINITE);	// サブ・スレッドの計算終了の合図を待つ
		th->off += 1;	// 計算を開始するソース・ブロックの番号
		if (th->off > 0){
			while (s_blk[th->off].size <= block_off){	// 計算不要なソース・ブロックはとばす
				prog_num += part_num;
				th->off += 1;
#ifdef TIMER
skip_count++;
#endif
			}
		} else {	// エラーや実験時以外は th->off は 0 にならない
			memset(p_buf, 0, (size_t)unit_size * part_num);
		}
#ifdef TIMER
		j = (th->off * 1000) / source_num;
		printf("partial encode = %d (%d.%d%%), read = %d, skip = %d\n", th->off, j / 10, j % 10, read_count, skip_count);
#endif

		// リカバリ・ファイルに書き込むサイズ
		if (block_size - block_off < io_size){
			len = block_size - block_off;
		} else {
			len = io_size;
		}

		// cover_num ごとに処理する
		part_start = 0;
		cover_from = 0;
		cover_num = cpu_num;	// part_num は cover_num (cpu_num) の倍数にすること
		src_num = source_num - th->off;	// 一度に処理する量 (src_num > 0)
		printf("part_start = %d, src_num = %d / %d, cover_num = %d\n", part_start, src_num, source_num, cover_num);
		th->buf = buf + (size_t)unit_size * (th->off);
		th->count = src_num;	// (part_start << 16) | src_num;
		while (part_start + cover_from < parity_num){
			if (cover_from >= part_num){	// part_num 分の計算が終わったら
				th->off = 0;	// 最初の計算以降は全てのソース・ブロックを対象にする
				part_start += part_num;
				cover_from = 0;
				src_num = source_num;	// source_num - th->off
				th->buf = buf;	// buf + (size_t)unit_size * (th->off);
				th->count = (part_start << 16) | src_num;
				printf("part_start = %d, src_num = %d\n", part_start, src_num);
			}
			if (part_start + cover_from + cover_num > parity_num)
				cover_num = parity_num - part_start - cover_from;
			//printf("cover_from = %d, cover_num = %d\n", cover_from, cover_num);

			// スレッドごとにパリティ・ブロックを計算する
			th->size = (cover_num << 16) | cover_from;
			th->now = -1;	// 初期値 - 1
			//_mm_sfence();
			for (j = 0; j < cpu_num; j++){
				ResetEvent(hEnd[j]);	// リセットしておく
				SetEvent(hRun[j]);	// サブ・スレッドに計算を開始させる
			}
			WaitForMultipleObjects(cpu_num, hEnd, TRUE, INFINITE);	// サブ・スレッドの計算終了の合図を待つ

			// 経過表示
			prog_num += src_num * cover_num;
			if (GetTickCount() - time_last >= UPDATE_TIME){
				if (print_progress((int)(((__int64)prog_num * 1000) / prog_base))){
					err = 2;
					goto error_end;
				}
				time_last = GetTickCount();
			}

#ifdef TIMER
time_start = GetTickCount();
#endif
			// パリティ・ブロックを書き込む
			work_buf = p_buf + (size_t)unit_size * cover_from;
			for (i = part_start + cover_from; i < part_start + cover_from + cover_num; i++){
				// パリティ・ブロックのチェックサムを検証する
				checksum16_return(work_buf, hash, io_size);
				if (memcmp(work_buf + io_size, hash, HASH_SIZE) != 0){
					printf("checksum mismatch, recovery slice %d\n", i);
					err = 1;
					goto error_end;
				}
				// ハッシュ値を計算して、リカバリ・ファイルに書き込む
				if (io_size >= block_size){	// 1回で書き込みが終わるなら
					Phmd5Begin(&md_ctx);
					j = first_num + i;	// 最初の番号の分だけ足す
					memcpy(header_buf + 64, &j, 4);	// Recovery Slice の番号を書き込む
					Phmd5Process(&md_ctx, header_buf + 32, 36);
					Phmd5Process(&md_ctx, work_buf, len);
					Phmd5End(&md_ctx);
					memcpy(header_buf + 16, md_ctx.hash, 16);
					// ヘッダーを書き込む
					if (file_write_data(rcv_hFile[p_blk[i].file], p_blk[i].off + block_off - 68, header_buf, 68)){
						printf("file_write_data, recovery slice %d\n", i);
						err = 1;
						goto error_end;
					}
				} else {
					Phmd5Process(&(md_ptr[i]), work_buf, len);
				}
				//printf("%d, buf = %p, size = %u, off = %I64d\n", i, work_buf, len, p_blk[i].off + block_off);
				if (file_write_data(rcv_hFile[p_blk[i].file], p_blk[i].off + block_off, work_buf, len)){
					printf("file_write_data, recovery slice %d\n", i);
					err = 1;
					goto error_end;
				}
				work_buf += unit_size;
			}
#ifdef TIMER
time_write += GetTickCount() - time_start;
#endif

			cover_from += cover_num;	// 次のパリティ位置にする
		}

		block_off += io_size;
	}
	print_progress_done();	// 改行して行の先頭に戻しておく

	// ファイルごとにブロックの CRC-32 を検証する
	memset(buf, 0, io_size);
	j = 0;
	while (j < source_num){
		last_file = s_blk[j].file;
		src_num = (int)((files[last_file].size + (__int64)block_size - 1) / block_size);
		i = j + src_num - 1;	// 末尾ブロックの番号
		if (s_blk[i].size < block_size){	// 残りを 0 でパディングする
			len = block_size - s_blk[i].size;
			while (len > io_size){
				len -= io_size;
				s_blk[i].crc = crc_update(s_blk[i].crc, buf, io_size);
			}
			s_blk[i].crc = crc_update(s_blk[i].crc, buf, len);
		}
		memset(hash, 0, 16);
		for (i = 0; i < src_num; i++)	// XOR して 16バイトに減らす
			((unsigned int *)hash)[i & 3] ^= s_blk[j + i].crc ^ 0xFFFFFFFF;
		if (memcmp(files[last_file].hash, hash, 16) != 0){
			printf("checksum mismatch, input file %d\n", last_file);
			err = 1;
			goto error_end;
		}
		j += src_num;
	}

	//printf("io_size = %d, block_size = %d\n", io_size, block_size);
	if (io_size < block_size){	// 1回で書き込みが終わらなかったなら
		if (GetTickCount() - time_last >= UPDATE_TIME){	// キャンセルを受け付ける
			if (cancel_progress()){
				err = 2;
				goto error_end;
			}
		}

#ifdef TIMER
time_start = GetTickCount();
#endif
		// 最後に Recovery Slice packet のヘッダーを書き込む
		for (i = 0; i < parity_num; i++){
			Phmd5End(&(md_ptr[i]));
			memcpy(header_buf + 16, md_ptr[i].hash, 16);
			j = first_num + i;	// 最初のパリティ・ブロック番号の分だけ足す
			memcpy(header_buf + 64, &j, 4);	// Recovery Slice の番号を書き込む
			// リカバリ・ファイルに書き込む
			if (file_write_data(rcv_hFile[p_blk[i].file], p_blk[i].off - 68, header_buf, 68)){	// ヘッダーのサイズ分だけずらす
				printf("file_write_data, packet header\n");
				err = 1;
				goto error_end;
			}
		}
#ifdef TIMER
time_write += GetTickCount() - time_start;
#endif
	}

#ifdef TIMER
printf("read   %d.%03d sec\n", time_read / 1000, time_read % 1000);
printf("write  %d.%03d sec\n", time_write / 1000, time_write % 1000);
#endif

error_end:
	InterlockedExchange(&(th->now), INT_MAX / 2);	// サブ・スレッドの計算を中断する
	for (j = 0; j < cpu_num; j++){
		if (hSub[j]){	// サブ・スレッドを終了させる
			SetEvent(hRun[j]);
			WaitForSingleObject(hSub[j], INFINITE);
			CloseHandle(hSub[j]);
		}
	}
	if (md_ptr)
		free(md_ptr);
	if (hFile)
		CloseHandle(hFile);
	if (buf)
		_aligned_free(buf);
	return err;
}

// ダブル・バッファリングで cover_num ごとに計算して書き込むバージョン
int encode_method8d(	// ソース・データを全て読み込む場合 (chunkごと)
	wchar_t *file_path,
	unsigned char *header_buf,	// Recovery Slice packet のパケット・ヘッダー
	HANDLE *rcv_hFile,			// リカバリ・ファイルのハンドル
	file_ctx_c *files,			// ソース・ファイルの情報
	source_ctx_c *s_blk,		// ソース・ブロックの情報
	parity_ctx_c *p_blk,		// パリティ・ブロックの情報
	unsigned short *constant)	// 複数ブロック分の領域を確保しておく？
{
	unsigned char *buf = NULL, *p_buf, *work_buf, *hash;
	unsigned short *factor1;
	int err = 0, i, j, last_file, part_start, part_num;
	int src_num, cover_from, cover_num, write_start, write_from, write_num;
	unsigned int io_size, unit_size, len, block_off;
	unsigned int time_last;
	__int64 file_off, prog_num = 0, prog_base;
	HANDLE hFile = NULL;
	HANDLE hSub[MAX_CPU], hRun[MAX_CPU], hEnd[MAX_CPU];
	RS_TH th[1];
	PHMD5 md_ctx, *md_ptr = NULL;

	memset(hSub, 0, sizeof(HANDLE) * MAX_CPU);
	factor1 = constant + source_num;

	// 作業バッファーを確保する
	part_num = source_num >> PART_MAX_RATE;	// ソース・ブロック数に対する割合で最大量を決める
	part_num = ((part_num + cpu_num - 1) / cpu_num) * cpu_num;	// cpu_num の倍数にする
	if (part_num < cpu_num * PART_MIN_NUM)
		part_num = cpu_num * PART_MIN_NUM;	// part_num を cpu_num の２倍以上にすれば、ダブル・バッファリングできる
	if (part_num > parity_num)
		part_num = parity_num;
	io_size = get_io_size(source_num, &part_num, 1, sse_unit);
	//io_size = (((io_size + 1) / 2 + HASH_SIZE + (sse_unit - 1)) & ~(sse_unit - 1)) - HASH_SIZE;	// 2分割の実験用
	//io_size = (((io_size + 2) / 3 + HASH_SIZE + (sse_unit - 1)) & ~(sse_unit - 1)) - HASH_SIZE;	// 3分割の実験用
	unit_size = io_size + HASH_SIZE;	// チェックサムの分だけ増やす
	file_off = (source_num + part_num) * (size_t)unit_size + HASH_SIZE;
	buf = _aligned_malloc((size_t)file_off, sse_unit);
	if (buf == NULL){
		printf("malloc, %I64d\n", file_off);
		err = 1;
		goto error_end;
	}
	p_buf = buf + (size_t)unit_size * source_num;	// パリティ・ブロックを記録する領域
	hash = p_buf + (size_t)unit_size * part_num;
	prog_base = (block_size + io_size - 1) / io_size;
	prog_base *= source_num * parity_num;	// 全体の断片の個数
	len = try_cache_blocking(unit_size);
	//len = ((len + 2) / 3 + (sse_unit - 1)) & ~(sse_unit - 1);	// 1/3の実験用
#ifdef TIMER
	printf("\n read all source blocks, and keep some parity blocks (chunk)\n");
	printf("buffer size = %I64d MB, io_size = %d, split = %d\n", file_off >> 20, io_size, (block_size + io_size - 1) / io_size);
	printf("cache: limit size = %d, chunk_size = %d, split = %d\n", cpu_flag & 0x7FFF8000, len, (unit_size + len - 1) / len);
	printf("prog_base = %I64d, unit_size = %d, part_num = %d\n", prog_base, unit_size, part_num);
#endif

	if (io_size < block_size){	// スライスが分割される場合だけ、途中までのハッシュ値を保持する
		block_off = sizeof(PHMD5) * parity_num;
		md_ptr = malloc(block_off);
		if (md_ptr == NULL){
			printf("malloc, %d\n", block_off);
			err = 1;
			goto error_end;
		}
		for (i = 0; i < parity_num; i++){
			Phmd5Begin(&(md_ptr[i]));
			j = first_num + i;	// 最初の番号の分だけ足す
			memcpy(header_buf + 64, &j, 4);	// Recovery Slice の番号を書き込む
			Phmd5Process(&(md_ptr[i]), header_buf + 32, 36);
		}
	}

	// マルチ・スレッドの準備をする
	th->mat = constant;
	th->buf = p_buf;
	th->size = unit_size;
	th->count = part_num;
	th->off = len;	// キャッシュの最適化を試みる
	for (j = 0; j < cpu_num; j++){	// サブ・スレッドごとに
		hRun[j] = CreateEvent(NULL, FALSE, FALSE, NULL);	// Auto Reset にする
		if (hRun[j] == NULL){
			print_win32_err();
			printf("error, sub-thread\n");
			err = 1;
			goto error_end;
		}
		hEnd[j] = CreateEvent(NULL, TRUE, FALSE, NULL);
		if (hEnd[j] == NULL){
			print_win32_err();
			CloseHandle(hRun[j]);
			printf("error, sub-thread\n");
			err = 1;
			goto error_end;
		}
		// サブ・スレッドを起動する
		th->run = hRun[j];
		th->end = hEnd[j];
		th->now = j;	// スレッド番号
		//_mm_sfence();	// メモリーへの書き込みを完了してからスレッドを起動する
		hSub[j] = (HANDLE)_beginthreadex(NULL, STACK_SIZE, thread_encode_chunk2, (LPVOID)th, 0, NULL);
		if (hSub[j] == NULL){
			print_win32_err();
			CloseHandle(hRun[j]);
			CloseHandle(hEnd[j]);
			printf("error, sub-thread\n");
			err = 1;
			goto error_end;
		}
		WaitForSingleObject(hEnd[j], INFINITE);	// 設定終了の合図を待つ (リセットしない)
	}
	// IO が延滞しないように、サブ・スレッド一つの優先度を下げる
	SetThreadPriority(hSub[0], THREAD_PRIORITY_BELOW_NORMAL);

	// ソース・ブロック断片を読み込んで、パリティ・ブロック断片を作成する
	time_last = GetTickCount();
	wcscpy(file_path, base_dir);
	block_off = 0;
	while (block_off < block_size){
		th->size = 0;	// 1st encode
		th->off = -1;	// まだ計算して無い印

		// ソース・ブロックを読み込む
#ifdef TIMER
read_count = 0;
skip_count = 0;
time_start = GetTickCount();
#endif
		last_file = -1;
		for (i = 0; i < source_num; i++){
			if (s_blk[i].file != last_file){	// 別のファイルなら開く
				last_file = s_blk[i].file;
				if (hFile){
					CloseHandle(hFile);	// 前のファイルを閉じる
					hFile = NULL;
				}
				wcscpy(file_path + base_len, list_buf + files[last_file].name);
				hFile = CreateFile(file_path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
				if (hFile == INVALID_HANDLE_VALUE){
					print_win32_err();
					hFile = NULL;
					printf_cp("cannot open file, %s\n", list_buf + files[last_file].name);
					err = 1;
					goto error_end;
				}
				file_off = block_off;
			} else {	// 同じファイルならブロック・サイズ分ずらす
				file_off += block_size;
			}
			if (s_blk[i].size > block_off){	// バッファーにソース・ファイルの内容を読み込む
				len = s_blk[i].size - block_off;
				if (len > io_size)
					len = io_size;
				if (file_read_data(hFile, file_off, buf + (size_t)unit_size * i, len)){
					printf("file_read_data, input slice %d\n", i);
					err = 1;
					goto error_end;
				}
				if (len < io_size)
					memset(buf + ((size_t)unit_size * i + len), 0, io_size - len);
				// ソース・ブロックのチェックサムを計算する
				if (block_off == 0)
					s_blk[i].crc = 0xFFFFFFFF;
				s_blk[i].crc = crc_update(s_blk[i].crc, buf + (size_t)unit_size * i, len);	// without pad
				checksum16_altmap(buf + (size_t)unit_size * i, buf + ((size_t)unit_size * i + io_size), io_size);
#ifdef TIMER
read_count++;
#endif

				if (i + 1 < source_num){	// 最後のブロック以外なら
					// サブ・スレッドの動作状況を調べる
					j = WaitForMultipleObjects((cpu_num + 1) / 2, hEnd, TRUE, 0);
					if ((j != WAIT_TIMEOUT) && (j != WAIT_FAILED)){	// 計算中でないなら
						// 経過表示
						prog_num += part_num;
						if (GetTickCount() - time_last >= UPDATE_TIME){
							if (print_progress((int)((prog_num * 1000) / prog_base))){
								err = 2;
								goto error_end;
							}
							time_last = GetTickCount();
						}
						// 計算終了したブロックの次から計算を開始する
						th->off += 1;
						if (th->off > 0){	// バッファーに読み込んだ時だけ計算する
							while (s_blk[th->off].size <= block_off){
								prog_num += part_num;
								th->off += 1;
#ifdef TIMER
skip_count++;
#endif
							}
						}
						th->buf = buf + (size_t)unit_size * th->off;
						for (j = 0; j < part_num; j++)
							factor1[j] = galois_power(constant[th->off], first_num + j);	// factor は定数行列の乗数になる
						th->now = -1;	// 初期値 - 1
						//_mm_sfence();
						for (j = 0; j < (cpu_num + 1) / 2; j++){
							ResetEvent(hEnd[j]);	// リセットしておく
							SetEvent(hRun[j]);	// サブ・スレッドに計算を開始させる
						}
					}
				}
			} else {
				memset(buf + (size_t)unit_size * i, 0, unit_size);
			}
		}
		// 最後のソース・ファイルを閉じる
		CloseHandle(hFile);
		hFile = NULL;
#ifdef TIMER
time_read += GetTickCount() - time_start;
#endif

		WaitForMultipleObjects((cpu_num + 1) / 2, hEnd, TRUE, INFINITE);	// サブ・スレッドの計算終了の合図を待つ
		th->off += 1;	// 計算を開始するソース・ブロックの番号
		if (th->off > 0){
			while (s_blk[th->off].size <= block_off){	// 計算不要なソース・ブロックはとばす
				prog_num += part_num;
				th->off += 1;
#ifdef TIMER
skip_count++;
#endif
			}
		} else {	// エラーや実験時以外は th->off は 0 にならない
			memset(p_buf, 0, (size_t)unit_size * part_num);
		}
#ifdef TIMER
		j = (th->off * 1000) / source_num;
		printf("partial encode = %d (%d.%d%%), read = %d, skip = %d\n", th->off, j / 10, j % 10, read_count, skip_count);
#endif

		// リカバリ・ファイルに書き込むサイズ
		if (block_size - block_off < io_size){
			len = block_size - block_off;
		} else {
			len = io_size;
		}

		// 最初のパリティの計算を始めておく
		part_start = 0;
		cover_from = 0;
		cover_num = cpu_num;	// part_num は cover_num (cpu_num) の倍数にすること
		if (cover_num > parity_num)
			cover_num = parity_num;
		src_num = source_num - th->off;	// 一度に処理する量 (src_num > 0)
		th->buf = buf + (size_t)unit_size * (th->off);
		th->count = src_num;	// (part_start << 16) | src_num;
		printf("part_start = %d, source = %d / %d, cover_num = %d\n", part_start, src_num, source_num, cover_num);
		th->size = cover_num << 16;
		th->now = -1;	// 初期値 - 1
		//_mm_sfence();
		for (j = 0; j < cpu_num; j++){
			ResetEvent(hEnd[j]);	// リセットしておく
			SetEvent(hRun[j]);	// サブ・スレッドに計算を開始させる
		}

		while (part_start + cover_from < parity_num){
			WaitForMultipleObjects(cpu_num, hEnd, TRUE, INFINITE);	// サブ・スレッドの計算終了の合図を待つ
			// 計算結果を書き込んだ場所を記録しておく
			write_start = part_start;
			write_from = cover_from;
			write_num = cover_num;
			cover_from += cover_num;	// 次のパリティ位置にする

			// 最後のブロック以外なら、次のパリティの計算を開始しておく
			if (part_start + cover_from < parity_num){
				// 経過表示
				prog_num += src_num * cover_num;
				if (GetTickCount() - time_last >= UPDATE_TIME){
					if (print_progress((int)(((__int64)prog_num * 1000) / prog_base))){
						err = 2;
						goto error_end;
					}
					time_last = GetTickCount();
				}

				if (cover_from >= part_num){	// part_num 分の計算が終わったら
					th->off = 0;	// 最初の計算以降は全てのソース・ブロックを対象にする
					part_start += part_num;
					cover_from = 0;
					src_num = source_num;	// source_num - th->off
					th->buf = buf;	// buf + (size_t)unit_size * (th->off);
					th->count = (part_start << 16) | src_num;
					printf("part_start = %d, source = %d / %d\n", part_start, src_num, source_num);
				}
				if (part_start + cover_from + cover_num > parity_num)
					cover_num = parity_num - part_start - cover_from;
				//printf("cover_from = %d, cover_num = %d\n", cover_from, cover_num);

				// スレッドごとにパリティ・ブロックを計算する
				th->size = (cover_num << 16) | cover_from;
				th->now = -1;	// 初期値 - 1
				//_mm_sfence();
				for (j = 0; j < cpu_num; j++){
					ResetEvent(hEnd[j]);	// リセットしておく
					SetEvent(hRun[j]);	// サブ・スレッドに計算を開始させる
				}
			}

#ifdef TIMER
time_start = GetTickCount();
#endif
			// パリティ・ブロックを書き込む
			//printf("write_start = %d, write_from = %d, write_num = %d\n", write_start, write_from, write_num);
			work_buf = p_buf + (size_t)unit_size * write_from;
			for (i = write_start + write_from; i < write_start + write_from + write_num; i++){
				// パリティ・ブロックのチェックサムを検証する
				checksum16_return(work_buf, hash, io_size);
				if (memcmp(work_buf + io_size, hash, HASH_SIZE) != 0){
					printf("checksum mismatch, recovery slice %d\n", i);
					err = 1;
					goto error_end;
				}
				// ハッシュ値を計算して、リカバリ・ファイルに書き込む
				if (io_size >= block_size){	// 1回で書き込みが終わるなら
					Phmd5Begin(&md_ctx);
					j = first_num + i;	// 最初の番号の分だけ足す
					memcpy(header_buf + 64, &j, 4);	// Recovery Slice の番号を書き込む
					Phmd5Process(&md_ctx, header_buf + 32, 36);
					Phmd5Process(&md_ctx, work_buf, len);
					Phmd5End(&md_ctx);
					memcpy(header_buf + 16, md_ctx.hash, 16);
					// ヘッダーを書き込む
					if (file_write_data(rcv_hFile[p_blk[i].file], p_blk[i].off + block_off - 68, header_buf, 68)){
						printf("file_write_data, recovery slice %d\n", i);
						err = 1;
						goto error_end;
					}
				} else {
					Phmd5Process(&(md_ptr[i]), work_buf, len);
				}
				//printf("%d, buf = %p, size = %u, off = %I64d\n", i, work_buf, len, p_blk[i].off + block_off);
				if (file_write_data(rcv_hFile[p_blk[i].file], p_blk[i].off + block_off, work_buf, len)){
					printf("file_write_data, recovery slice %d\n", i);
					err = 1;
					goto error_end;
				}
				work_buf += unit_size;
			}
#ifdef TIMER
time_write += GetTickCount() - time_start;
#endif
		}

		block_off += io_size;
	}
	print_progress_done();	// 改行して行の先頭に戻しておく

	// ファイルごとにブロックの CRC-32 を検証する
	memset(buf, 0, io_size);
	j = 0;
	while (j < source_num){
		last_file = s_blk[j].file;
		src_num = (int)((files[last_file].size + (__int64)block_size - 1) / block_size);
		i = j + src_num - 1;	// 末尾ブロックの番号
		if (s_blk[i].size < block_size){	// 残りを 0 でパディングする
			len = block_size - s_blk[i].size;
			while (len > io_size){
				len -= io_size;
				s_blk[i].crc = crc_update(s_blk[i].crc, buf, io_size);
			}
			s_blk[i].crc = crc_update(s_blk[i].crc, buf, len);
		}
		memset(hash, 0, 16);
		for (i = 0; i < src_num; i++)	// XOR して 16バイトに減らす
			((unsigned int *)hash)[i & 3] ^= s_blk[j + i].crc ^ 0xFFFFFFFF;
		if (memcmp(files[last_file].hash, hash, 16) != 0){
			printf("checksum mismatch, input file %d\n", last_file);
			err = 1;
			goto error_end;
		}
		j += src_num;
	}

	//printf("io_size = %d, block_size = %d\n", io_size, block_size);
	if (io_size < block_size){	// 1回で書き込みが終わらなかったなら
		if (GetTickCount() - time_last >= UPDATE_TIME){	// キャンセルを受け付ける
			if (cancel_progress()){
				err = 2;
				goto error_end;
			}
		}

#ifdef TIMER
time_start = GetTickCount();
#endif
		// 最後に Recovery Slice packet のヘッダーを書き込む
		for (i = 0; i < parity_num; i++){
			Phmd5End(&(md_ptr[i]));
			memcpy(header_buf + 16, md_ptr[i].hash, 16);
			j = first_num + i;	// 最初のパリティ・ブロック番号の分だけ足す
			memcpy(header_buf + 64, &j, 4);	// Recovery Slice の番号を書き込む
			// リカバリ・ファイルに書き込む
			if (file_write_data(rcv_hFile[p_blk[i].file], p_blk[i].off - 68, header_buf, 68)){	// ヘッダーのサイズ分だけずらす
				printf("file_write_data, packet header\n");
				err = 1;
				goto error_end;
			}
		}
#ifdef TIMER
time_write += GetTickCount() - time_start;
#endif
	}

#ifdef TIMER
printf("read   %d.%03d sec\n", time_read / 1000, time_read % 1000);
printf("write  %d.%03d sec\n", time_write / 1000, time_write % 1000);
#endif

error_end:
	InterlockedExchange(&(th->now), INT_MAX / 2);	// サブ・スレッドの計算を中断する
	for (j = 0; j < cpu_num; j++){
		if (hSub[j]){	// サブ・スレッドを終了させる
			SetEvent(hRun[j]);
			WaitForSingleObject(hSub[j], INFINITE);
			CloseHandle(hSub[j]);
		}
	}
	if (md_ptr)
		free(md_ptr);
	if (hFile)
		CloseHandle(hFile);
	if (buf)
		_aligned_free(buf);
	return err;
}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
// 1ブロックずつ計算するバージョン

static DWORD WINAPI thread_encode2_single(LPVOID lpParameter)
{
	unsigned char *buf, *p_buf, *work_buf;
	volatile unsigned short *factor;
	int i, j, th_id, part_num, chunk_num, max_num, left_num, left_max;
	unsigned int unit_size, len, off, chunk_size;
	HANDLE hRun, hEnd;
	RS_TH *th;
#ifdef TIMER
unsigned int loop_count2a = 0, loop_count2b = 0;
unsigned int time_start2, time_encode2a = 0, time_encode2b = 0;
#endif

	th = (RS_TH *)lpParameter;
	factor = th->mat;
	buf = th->buf;
	unit_size = th->size;
	part_num = th->count;
	chunk_size = th->off;
	th_id = th->now;	// スレッド番号
	hRun = th->run;
	hEnd = th->end;
	//_mm_sfence();
	SetEvent(hEnd);	// 設定完了を通知する

	p_buf = buf + ((size_t)unit_size * (source_num + cpu_num - 1));
	chunk_num = (unit_size + chunk_size - 1) / chunk_size;
	max_num = chunk_num * part_num;
	if (th_id > 0)
		work_buf = buf + ((size_t)unit_size * (source_num + th_id - 1));

	WaitForSingleObject(hRun, INFINITE);	// 計算開始の合図を待つ
	while (th->now < INT_MAX / 2){
#ifdef TIMER
time_start2 = GetTickCount();
#endif
		i = th->off;	// ソース・ブロック番号
		len = chunk_size;
		if (th->buf == NULL){	// ソース・ブロック読み込み中
			// パリティ・ブロックごとに掛け算して追加していく
			while ((j = InterlockedIncrement(&(th->now))) < max_num){	// j = ++th_now
				off = j / part_num;	// chunk の番号
				j = j % part_num;	// parity の番号
				off *= chunk_size;
				if (off + len > unit_size)
					len = unit_size - off;	// 最後の chunk だけサイズが異なるかも
				if (i == 0)	// 最初のブロックを計算する際に
					memset(p_buf + ((size_t)unit_size * j + off), 0, len);	// ブロックを 0で埋める
				galois_align_multiply(buf + ((size_t)unit_size * i + off), p_buf + ((size_t)unit_size * j + off), len, factor[j]);
#ifdef TIMER
loop_count2a++;
#endif
			}
#ifdef TIMER
time_encode2a += GetTickCount() - time_start2;
#endif
		} else {	// パリティ・ブロック書き込み中
			if (th_id == 0){
				work_buf = th->buf;
				if (i == 0)	// 最初から計算する場合はブロックを 0で埋める
					memset(work_buf, 0, unit_size);
			} else {
				memset(work_buf, 0, unit_size);	// ブロックを 0で埋める
			}
			left_num = source_num - i;	// 残りブロック数
			left_max = chunk_num * left_num;
			// ソース・ブロックごとに掛け算して追加していく
			while ((j = InterlockedIncrement(&(th->now))) < left_max){	// j = ++th_now
				off = j / left_num;	// chunk の番号
				j = j % left_num;	// source の番号
				off *= chunk_size;
				if (off + len > unit_size)
					len = unit_size - off;	// 最後の chunk だけサイズが異なるかも
				galois_align_multiply(buf + ((size_t)unit_size * (i + j) + off), work_buf + off, len, factor[i + j]);
#ifdef TIMER
loop_count2b++;
#endif
			}
#ifdef TIMER
time_encode2b += GetTickCount() - time_start2;
#endif
		}
		//_mm_sfence();	// メモリーへの書き込みを完了する
		SetEvent(hEnd);	// 計算終了を通知する
		WaitForSingleObject(hRun, INFINITE);	// 計算開始の合図を待つ
	}
#ifdef TIMER
printf("sub-thread[%d] : total loop = %d\n", th_id, loop_count2a + loop_count2b);
if (time_encode2a > 0){
	i = (int)((__int64)loop_count2a * chunk_size * 125 / ((__int64)time_encode2a * 131072));
} else {
	i = 0;
}
if (loop_count2a > 0)
	printf(" 1st encode %d.%03d sec, %d loop, %d MB/s\n", time_encode2a / 1000, time_encode2a % 1000, loop_count2a, i);
if (time_encode2b > 0){
	i = (int)((__int64)loop_count2b * chunk_size * 125 / ((__int64)time_encode2b * 131072));
} else {
	i = 0;
}
printf(" 2nd encode %d.%03d sec, %d loop, %d MB/s\n", time_encode2b / 1000, time_encode2b % 1000, loop_count2b, i);
#endif

	// 終了処理
	CloseHandle(hRun);
	CloseHandle(hEnd);
	return 0;
}

static DWORD WINAPI thread_encode3_single(LPVOID lpParameter)
{
	unsigned char *buf, *p_buf, *work_buf;
	volatile unsigned short *factor;
	int i, j, th_id, chunk_num, max_num, left_num, left_max;
	unsigned int unit_size, len, off, chunk_size;
	HANDLE hRun, hEnd;
	RS_TH *th;
#ifdef TIMER
unsigned int loop_count2a = 0, loop_count2b = 0;
unsigned int time_start2, time_encode2a = 0, time_encode2b = 0;
#endif

	th = (RS_TH *)lpParameter;
	factor = th->mat;
	buf = th->buf;
	unit_size = th->size;
	left_num = th->count;
	chunk_size = th->off;
	th_id = th->now;	// スレッド番号
	hRun = th->run;
	hEnd = th->end;
	//_mm_sfence();
	SetEvent(hEnd);	// 設定完了を通知する

	p_buf = buf + (size_t)unit_size * (left_num + cpu_num - 1);
	chunk_num = (unit_size + chunk_size - 1) / chunk_size;
	max_num = chunk_num * parity_num;
	if (th_id > 0)
		work_buf = buf + (size_t)unit_size * (left_num + th_id - 1);

	WaitForSingleObject(hRun, INFINITE);	// 計算開始の合図を待つ
	while (th->now < INT_MAX / 2){
#ifdef TIMER
time_start2 = GetTickCount();
#endif
		i = th->off;	// ソース・ブロック番号
		len = chunk_size;
		if (th->buf == NULL){	// ソース・ブロック読み込み中
			left_num = th->count + i;
			// パリティ・ブロックごとに掛け算して追加していく
			while ((j = InterlockedIncrement(&(th->now))) < max_num){	// j = ++th_now
				off = j / parity_num;	// chunk の番号
				j = j % parity_num;		// parity の番号
				off *= chunk_size;
				if (off + len > unit_size)
					len = unit_size - off;	// 最後の chunk だけサイズが異なるかも
				if (left_num == 0)	// 最初のブロックを計算する際にブロックを 0で埋める
					memset(p_buf + ((size_t)unit_size * j + off), 0, len);	// ブロックを 0で埋める
				galois_align_multiply(buf + ((size_t)unit_size * i + off), p_buf + ((size_t)unit_size * j + off), len, factor[j]);
#ifdef TIMER
loop_count2a++;
#endif
			}
#ifdef TIMER
time_encode2a += GetTickCount() - time_start2;
#endif
		} else {	// パリティ・ブロック書き込み中
			if (th_id == 0){
				work_buf = th->buf;
			} else {
				memset(work_buf, 0, unit_size);	// ブロックを 0で埋める
			}
			left_num = th->count - i;	// 残りブロック数
			left_max = chunk_num * left_num;
			// ソース・ブロックごとに掛け算して追加していく
			while ((j = InterlockedIncrement(&(th->now))) < left_max){	// j = ++th_now
				off = j / left_num;	// chunk の番号
				j = j % left_num;	// source の番号
				off *= chunk_size;
				if (off + len > unit_size)
					len = unit_size - off;	// 最後の chunk だけサイズが異なるかも
				galois_align_multiply(buf + ((size_t)unit_size * (i + j) + off), work_buf + off, len, factor[i + j]);
#ifdef TIMER
loop_count2b++;
#endif
			}
#ifdef TIMER
time_encode2b += GetTickCount() - time_start2;
#endif
		}
		//_mm_sfence();	// メモリーへの書き込みを完了する
		SetEvent(hEnd);	// 計算終了を通知する
		WaitForSingleObject(hRun, INFINITE);	// 計算開始の合図を待つ
	}
#ifdef TIMER
printf("sub-thread[%d] : total loop = %d\n", th_id, loop_count2a + loop_count2b);
if (time_encode2a > 0){
	i = (int)((__int64)loop_count2a * chunk_size * 125 / ((__int64)time_encode2a * 131072));
} else {
	i = 0;
}
if (loop_count2a > 0)
	printf(" 1st encode %d.%03d sec, %d loop, %d MB/s\n", time_encode2a / 1000, time_encode2a % 1000, loop_count2a, i);
if (time_encode2b > 0){
	i = (int)((__int64)loop_count2b * chunk_size * 125 / ((__int64)time_encode2b * 131072));
} else {
	i = 0;
}
printf(" 2nd encode %d.%03d sec, %d loop, %d MB/s\n", time_encode2b / 1000, time_encode2b % 1000, loop_count2b, i);
#endif

	// 終了処理
	CloseHandle(hRun);
	CloseHandle(hEnd);
	return 0;
}


int encode_method2_single(	// ソース・データを全て読み込む場合
	wchar_t *file_path,
	unsigned char *header_buf,	// Recovery Slice packet のパケット・ヘッダー
	HANDLE *rcv_hFile,			// リカバリ・ファイルのハンドル
	file_ctx_c *files,			// ソース・ファイルの情報
	source_ctx_c *s_blk,		// ソース・ブロックの情報
	parity_ctx_c *p_blk,		// パリティ・ブロックの情報
	unsigned short *constant)
{
	unsigned char *buf = NULL, *p_buf, *work_buf, *sub_buf, *hash;
	unsigned short *factor;
	int err = 0, i, j, last_file, part_num;
	unsigned int io_size, unit_size, len, block_off;
	unsigned int time_last;
	__int64 file_off, prog_num = 0, prog_base;
	HANDLE hFile = NULL;
	HANDLE hSub[MAX_CPU], hRun[MAX_CPU], hEnd[MAX_CPU];
	RS_TH th[1];
	PHMD5 md_ctx, *md_ptr = NULL;

	memset(hSub, 0, sizeof(HANDLE) * MAX_CPU);
	factor = constant + source_num;

	// 作業バッファーを確保する
	part_num = source_num >> PART_MAX_RATE;	// ソース・ブロック数に対する割合で最大量を決める
	if (part_num > parity_num)
		part_num = parity_num;
	i = source_num + (cpu_num - 1);	// ソース・ブロックとサブ・スレッドの作業領域が必要
	io_size = get_io_size(i, &part_num, 1, sse_unit);
	//io_size = (((io_size + 2) / 3 + HASH_SIZE + (sse_unit - 1)) & ~(sse_unit - 1)) - HASH_SIZE;	// 実験用
	unit_size = io_size + HASH_SIZE;	// チェックサムの分だけ増やす
	file_off = (i + part_num) * (size_t)unit_size + HASH_SIZE;
	buf = _aligned_malloc((size_t)file_off, sse_unit);
	if (buf == NULL){
		printf("malloc, %I64d\n", file_off);
		err = 1;
		goto error_end;
	}
	sub_buf = buf + (size_t)unit_size * source_num;	// サブ・スレッドの作業領域
	p_buf = sub_buf + (size_t)unit_size * (cpu_num - 1);	// パリティ・ブロックを部分的に記録する領域
	hash = p_buf + (size_t)unit_size * part_num;
	prog_base = (block_size + io_size - 1) / io_size;
	prog_base *= source_num * parity_num;	// 全体の断片の個数
#ifdef TIMER
	printf("\n read all source blocks, and keep some parity blocks (single)\n");
	printf("buffer size = %I64d MB, io_size = %d, split = %d\n", file_off >> 20, io_size, (block_size + io_size - 1) / io_size);
	len = try_cache_blocking(unit_size);
	printf("cache: limit size = %d, chunk_size = %d, split = %d\n", cpu_cache & 0x7FFF8000, len, (unit_size + len - 1) / len);
	printf("prog_base = %I64d, unit_size = %d, part_num = %d\n", prog_base, unit_size, part_num);
#endif

	if (io_size < block_size){	// スライスが分割される場合だけ、途中までのハッシュ値を保持する
		len = sizeof(PHMD5) * parity_num;
		md_ptr = malloc(len);
		if (md_ptr == NULL){
			printf("malloc, %d\n", len);
			err = 1;
			goto error_end;
		}
		for (i = 0; i < parity_num; i++){
			Phmd5Begin(&(md_ptr[i]));
			j = first_num + i;	// 最初の番号の分だけ足す
			memcpy(header_buf + 64, &j, 4);	// Recovery Slice の番号を書き込む
			Phmd5Process(&(md_ptr[i]), header_buf + 32, 36);
		}
	}

	// マルチ・スレッドの準備をする
	th->mat = factor;
	th->buf = buf;
	th->size = unit_size;
	th->count = part_num;
	th->off = try_cache_blocking(unit_size);	// キャッシュの最適化を試みる
	for (j = 0; j < cpu_num; j++){	// サブ・スレッドごとに
		hRun[j] = CreateEvent(NULL, FALSE, FALSE, NULL);	// Auto Reset にする
		if (hRun[j] == NULL){
			print_win32_err();
			printf("error, sub-thread\n");
			err = 1;
			goto error_end;
		}
		hEnd[j] = CreateEvent(NULL, TRUE, FALSE, NULL);
		if (hEnd[j] == NULL){
			print_win32_err();
			CloseHandle(hRun[j]);
			printf("error, sub-thread\n");
			err = 1;
			goto error_end;
		}
		// サブ・スレッドを起動する
		th->run = hRun[j];
		th->end = hEnd[j];
		th->now = j;	// スレッド番号
		//_mm_sfence();	// メモリーへの書き込みを完了してからスレッドを起動する
		hSub[j] = (HANDLE)_beginthreadex(NULL, STACK_SIZE, thread_encode2_single, (LPVOID)th, 0, NULL);
		if (hSub[j] == NULL){
			print_win32_err();
			CloseHandle(hRun[j]);
			CloseHandle(hEnd[j]);
			printf("error, sub-thread\n");
			err = 1;
			goto error_end;
		}
		WaitForSingleObject(hEnd[j], INFINITE);	// 設定終了の合図を待つ (リセットしない)
	}
	// IO が延滞しないように、サブ・スレッド一つの優先度を下げる
	SetThreadPriority(hSub[0], THREAD_PRIORITY_BELOW_NORMAL);

	// ソース・ブロック断片を読み込んで、パリティ・ブロック断片を作成する
	time_last = GetTickCount();
	wcscpy(file_path, base_dir);
	block_off = 0;
	while (block_off < block_size){
		th->buf = NULL;
		th->off = -1;	// まだ計算して無い印

		// ソース・ブロックを読み込む
#ifdef TIMER
read_count = 0;
skip_count = 0;
time_start = GetTickCount();
#endif
		last_file = -1;
		for (i = 0; i < source_num; i++){
			if (s_blk[i].file != last_file){	// 別のファイルなら開く
				last_file = s_blk[i].file;
				if (hFile){
					CloseHandle(hFile);	// 前のファイルを閉じる
					hFile = NULL;
				}
				wcscpy(file_path + base_len, list_buf + files[last_file].name);
				hFile = CreateFile(file_path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
				if (hFile == INVALID_HANDLE_VALUE){
					print_win32_err();
					hFile = NULL;
					printf_cp("cannot open file, %s\n", list_buf + files[last_file].name);
					err = 1;
					goto error_end;
				}
				file_off = block_off;
			} else {	// 同じファイルならブロック・サイズ分ずらす
				file_off += block_size;
			}
			if (s_blk[i].size > block_off){	// バッファーにソース・ファイルの内容を読み込む
				len = s_blk[i].size - block_off;
				if (len > io_size)
					len = io_size;
				if (file_read_data(hFile, file_off, buf + (size_t)unit_size * i, len)){
					printf("file_read_data, input slice %d\n", i);
					err = 1;
					goto error_end;
				}
				if (len < io_size)
					memset(buf + ((size_t)unit_size * i + len), 0, io_size - len);
				// ソース・ブロックのチェックサムを計算する
				if (block_off == 0)
					s_blk[i].crc = 0xFFFFFFFF;
				s_blk[i].crc = crc_update(s_blk[i].crc, buf + (size_t)unit_size * i, len);	// without pad
				checksum16_altmap(buf + (size_t)unit_size * i, buf + ((size_t)unit_size * i + io_size), io_size);
#ifdef TIMER
read_count++;
#endif

				if (i + 1 < source_num){	// 最後のブロック以外なら
					// サブ・スレッドの動作状況を調べる
					j = WaitForMultipleObjects((cpu_num + 1) / 2, hEnd, TRUE, 0);
					if ((j != WAIT_TIMEOUT) && (j != WAIT_FAILED)){	// 計算中でないなら
						// 経過表示
						prog_num += part_num;
						if (GetTickCount() - time_last >= UPDATE_TIME){
							if (print_progress((int)((prog_num * 1000) / prog_base))){
								err = 2;
								goto error_end;
							}
							time_last = GetTickCount();
						}
						// 計算終了したブロックの次から計算を開始する
						th->off += 1;
						if (th->off > 0){	// バッファーに読み込んだ時だけ計算する
							while (s_blk[th->off].size <= block_off){
								prog_num += part_num;
								th->off += 1;
#ifdef TIMER
skip_count++;
#endif
							}
						}
						for (j = 0; j < part_num; j++)
							factor[j] = galois_power(constant[th->off], first_num + j);	// factor は定数行列の乗数になる
						th->now = -1;	// 初期値 - 1
						//_mm_sfence();	// メモリーへの書き込みを完了してからスレッドを再開する
						for (j = 0; j < (cpu_num + 1) / 2; j++){	// 読み込み中はスレッド数を減らす
							ResetEvent(hEnd[j]);	// リセットしておく
							SetEvent(hRun[j]);	// サブ・スレッドに計算を開始させる
						}
					}
				}
			} else {
				memset(buf + (size_t)unit_size * i, 0, unit_size);
			}
		}
		// 最後のソース・ファイルを閉じる
		CloseHandle(hFile);
		hFile = NULL;
#ifdef TIMER
time_read += GetTickCount() - time_start;
#endif

		WaitForMultipleObjects((cpu_num + 1) / 2, hEnd, TRUE, INFINITE);	// サブ・スレッドの計算終了の合図を待つ
		th->off += 1;	// 計算を開始するソース・ブロックの番号
		if (th->off > 0){
			while (s_blk[th->off].size <= block_off){	// 計算不要なソース・ブロックはとばす
				prog_num += part_num;
				th->off += 1;
#ifdef TIMER
skip_count++;
#endif
			}
		}
#ifdef TIMER
		j = (th->off * 1000) / source_num;
		printf("partial encode = %d (%d.%d%%), read = %d, skip = %d\n", th->off, j / 10, j % 10, read_count, skip_count);
		// ここまでのパリティ・ブロックのチェックサムを検証する
/*		for (j = 0; j < part_num; j++){
			checksum16_return(p_buf + (size_t)unit_size * j, hash, io_size);
			if (memcmp(p_buf + ((size_t)unit_size * j + io_size), hash, HASH_SIZE) != 0){
				printf("checksum mismatch, recovery slice %d after 1st encode\n", j);
				err = 1;
				goto error_end;
			}
			galois_altmap_change(p_buf + (size_t)unit_size * j, unit_size);
		}*/
#endif

		// 経過表示
		prog_num += source_num - th->off;
		if (GetTickCount() - time_last >= UPDATE_TIME){
			if (print_progress((int)((prog_num * 1000) / prog_base))){
				err = 2;
				goto error_end;
			}
			time_last = GetTickCount();
		}

		// 最初のパリティの計算を始めておく
		work_buf = p_buf;
		for (j = 0; j < source_num; j++){
			if (s_blk[j].size <= block_off){
				factor[j] = 0;	// 掛け算しない
			} else {
				factor[j] = galois_power(constant[j], first_num);	// factor は定数行列の乗数になる
			}
		}
		th->buf = work_buf;
		th->now = -1;	// 初期値 - 1
		//_mm_sfence();
		for (j = 0; j < cpu_num; j++){
			ResetEvent(hEnd[j]);	// リセットしておく
			SetEvent(hRun[j]);	// サブ・スレッドに計算を開始させる
		}

		// リカバリ・ファイルに書き込むサイズ
		if (block_size - block_off < io_size){
			len = block_size - block_off;
		} else {
			len = io_size;
		}

		// パリティ・ブロックごとに
		for (i = 0; i < parity_num; i++){
			// パリティの計算が終わるのを待って完成させる
			WaitForMultipleObjects(cpu_num, hEnd, TRUE, INFINITE);	// サブ・スレッドの計算終了の合図を待つ
			for (j = 1; j < cpu_num; j++){
				// 最後にサブ・スレッドのバッファーを XOR する
				galois_align_xor(sub_buf + (size_t)unit_size * (j - 1), work_buf, unit_size);
			}
			if (i + 1 < parity_num){	// 最後のブロック以外なら
				if (i + 1 >= part_num){	// 部分的なエンコードを施した箇所以降なら
					if (th->buf != p_buf){	// エンコードと書き込みでダブル・バッファリングする
						th->buf = p_buf;
						th->off = 0;	// 最初のソース・ブロックから計算する
					} else {
						th->buf += unit_size;
					}
				} else {
					th->buf += unit_size;
				}
				// 経過表示
				prog_num += source_num - th->off;
				if (GetTickCount() - time_last >= UPDATE_TIME){
					if (print_progress((int)((prog_num * 1000) / prog_base))){
						err = 2;
						goto error_end;
					}
					time_last = GetTickCount();
				}
				// 次のパリティの計算を開始しておく
				for (j = 0; j < source_num; j++){
					if (s_blk[j].size <= block_off){
						factor[j] = 0;	// 掛け算しない
					} else {
						factor[j] = galois_power(constant[j], first_num + i + 1);	// factor は定数行列の乗数になる
					}
				}
				th->now = -1;	// 初期値 - 1
				//_mm_sfence();	// メモリーへの書き込みを完了してからスレッドを再開する
				for (j = 0; j < cpu_num; j++){
					ResetEvent(hEnd[j]);	// リセットしておく
					SetEvent(hRun[j]);	// サブ・スレッドに計算を開始させる
				}
			}

#ifdef TIMER
time_start = GetTickCount();
#endif
			// パリティ・ブロックのチェックサムを検証する
			checksum16_return(work_buf, hash, io_size);
			if (memcmp(work_buf + io_size, hash, HASH_SIZE) != 0){
				printf("checksum mismatch, recovery slice %d\n", i);
				err = 1;
				goto error_end;
			}
			// ハッシュ値を計算して、リカバリ・ファイルに書き込む
			if (io_size >= block_size){	// 1回で書き込みが終わるなら
				Phmd5Begin(&md_ctx);
				j = first_num + i;	// 最初の番号の分だけ足す
				memcpy(header_buf + 64, &j, 4);	// Recovery Slice の番号を書き込む
				Phmd5Process(&md_ctx, header_buf + 32, 36);
				Phmd5Process(&md_ctx, work_buf, len);
				Phmd5End(&md_ctx);
				memcpy(header_buf + 16, md_ctx.hash, 16);
				// ヘッダーを書き込む
				if (file_write_data(rcv_hFile[p_blk[i].file], p_blk[i].off + block_off - 68, header_buf, 68)){
					printf("file_write_data, recovery slice %d\n", i);
					err = 1;
					goto error_end;
				}
			} else {
				Phmd5Process(&(md_ptr[i]), work_buf, len);
			}
			//printf("%d, buf = %p, size = %u, off = %I64d\n", i, work_buf, len, p_blk[i].off + block_off);
			if (file_write_data(rcv_hFile[p_blk[i].file], p_blk[i].off + block_off, work_buf, len)){
				printf("file_write_data, recovery slice %d\n", i);
				err = 1;
				goto error_end;
			}
#ifdef TIMER
time_write += GetTickCount() - time_start;
#endif

			if (i + 1 >= part_num) {	// 部分的なエンコードを施した箇所以降なら
				if (work_buf != p_buf){	// エンコードと書き込みでダブル・バッファリングする
					work_buf = p_buf;
				} else {
					work_buf += unit_size;
				}
			} else {
				work_buf += unit_size;
			}
		}

		block_off += io_size;
	}
	print_progress_done();	// 改行して行の先頭に戻しておく

	// ファイルごとにブロックの CRC-32 を検証する
	memset(buf, 0, io_size);
	j = 0;
	while (j < source_num){
		last_file = s_blk[j].file;
		part_num = (int)((files[last_file].size + (__int64)block_size - 1) / block_size);
		i = j + part_num - 1;	// 末尾ブロックの番号
		if (s_blk[i].size < block_size){	// 残りを 0 でパディングする
			len = block_size - s_blk[i].size;
			while (len > io_size){
				len -= io_size;
				s_blk[i].crc = crc_update(s_blk[i].crc, buf, io_size);
			}
			s_blk[i].crc = crc_update(s_blk[i].crc, buf, len);
		}
		memset(hash, 0, 16);
		for (i = 0; i < part_num; i++)	// XOR して 16バイトに減らす
			((unsigned int *)hash)[i & 3] ^= s_blk[j + i].crc ^ 0xFFFFFFFF;
		if (memcmp(files[last_file].hash, hash, 16) != 0){
			printf("checksum mismatch, input file %d\n", last_file);
			err = 1;
			goto error_end;
		}
		j += part_num;
	}

	if (io_size < block_size){	// 1回で書き込みが終わらなかったなら
		if (GetTickCount() - time_last >= UPDATE_TIME){	// キャンセルを受け付ける
			if (cancel_progress()){
				err = 2;
				goto error_end;
			}
		}

#ifdef TIMER
time_start = GetTickCount();
#endif
		// 最後に Recovery Slice packet のヘッダーを書き込む
		for (i = 0; i < parity_num; i++){
			Phmd5End(&(md_ptr[i]));
			memcpy(header_buf + 16, md_ptr[i].hash, 16);
			j = first_num + i;	// 最初のパリティ・ブロック番号の分だけ足す
			memcpy(header_buf + 64, &j, 4);	// Recovery Slice の番号を書き込む
			// リカバリ・ファイルに書き込む
			if (file_write_data(rcv_hFile[p_blk[i].file], p_blk[i].off - 68, header_buf, 68)){	// ヘッダーのサイズ分だけずらす
				printf("file_write_data, packet header\n");
				err = 1;
				goto error_end;
			}
		}
#ifdef TIMER
time_write += GetTickCount() - time_start;
#endif
	}

#ifdef TIMER
printf("read   %d.%03d sec\n", time_read / 1000, time_read % 1000);
printf("write  %d.%03d sec\n", time_write / 1000, time_write % 1000);
#endif

error_end:
	InterlockedExchange(&(th->now), INT_MAX / 2);	// サブ・スレッドの計算を中断する
	for (j = 0; j < cpu_num; j++){
		if (hSub[j]){	// サブ・スレッドを終了させる
			SetEvent(hRun[j]);
			WaitForSingleObject(hSub[j], INFINITE);
			CloseHandle(hSub[j]);
		}
	}
	if (md_ptr)
		free(md_ptr);
	if (hFile)
		CloseHandle(hFile);
	if (buf)
		_aligned_free(buf);
	return err;
}

int encode_method3_single(	// パリティ・ブロックを全て保持して、一度に書き込む場合
	wchar_t *file_path,
	wchar_t *recovery_path,		// 作業用
	int packet_limit,			// リカバリ・ファイルのパケット繰り返しの制限
	int block_distri,			// パリティ・ブロックの分配方法 (3-bit目は番号の付け方)
	int packet_num,				// 共通パケットの数
	unsigned char *common_buf,	// 共通パケットのバッファー
	int common_size,			// 共通パケットのバッファー・サイズ
	unsigned char *footer_buf,	// 末尾パケットのバッファー
	int footer_size,			// 末尾パケットのバッファー・サイズ
	HANDLE *rcv_hFile,			// リカバリ・ファイルのハンドル
	file_ctx_c *files,			// ソース・ファイルの情報
	source_ctx_c *s_blk,		// ソース・ブロックの情報
	unsigned short *constant)
{
	unsigned char *buf = NULL, *p_buf, *work_buf, *sub_buf;
	unsigned short *factor;
	int err = 0, i, j, last_file, source_off, read_num, packet_off;
	unsigned int unit_size, len;
	unsigned int time_last, prog_write;
	__int64 prog_num = 0, prog_base;
	size_t mem_size;
	HANDLE hFile = NULL;
	HANDLE hSub[MAX_CPU], hRun[MAX_CPU], hEnd[MAX_CPU];
	RS_TH th[1];
	PHMD5 file_md_ctx, blk_md_ctx;

	memset(hSub, 0, sizeof(HANDLE) * MAX_CPU);
	factor = constant + source_num;
	unit_size = (block_size + HASH_SIZE + (sse_unit - 1)) & ~(sse_unit - 1);	// チェックサムの分だけ増やす

	// 作業バッファーを確保する
	read_num = read_block_num(parity_num, cpu_num - 1, 1, sse_unit);	// ソース・ブロックを何個読み込むか
	if (read_num == 0){
#ifdef TIMER
		printf("cannot keep enough blocks, use another method\n");
#endif
		return -2;	// スライスを分割して処理しないと無理
	}
	print_progress_text(0, "Creating recovery slice");
	//read_num = (read_num + 2) / 3 + 1;	// 実験用
	mem_size = read_num + parity_num + (cpu_num - 1);	// パリティ・ブロックとサブ・スレッドの作業領域が必要
	mem_size = mem_size * unit_size;
	buf = _aligned_malloc(mem_size, sse_unit);
	if (buf == NULL){
		printf("malloc, %Id\n", mem_size);
		err = 1;
		goto error_end;
	}
	sub_buf = buf + (size_t)unit_size * read_num;	// サブ・スレッドの作業領域
	p_buf = sub_buf + (size_t)unit_size * (cpu_num - 1);	// パリティ・ブロックを記録する領域
	prog_write = source_num >> 5;	// 計算で 97%、書き込みで 3% ぐらい
	if (prog_write == 0)
		prog_write = 1;
	prog_base = (__int64)(source_num + prog_write) * parity_num;	// ブロックの合計掛け算個数 + 書き込み回数
#ifdef TIMER
	printf("\n read some source blocks, and keep all parity blocks (single)\n");
	printf("buffer size = %Id MB, read_num = %d, round = %d\n", mem_size >> 20, read_num, (source_num + read_num - 1) / read_num);
	len = try_cache_blocking(unit_size);
	printf("cache: limit size = %d, chunk_size = %d, split = %d\n", cpu_cache & 0x7FFF8000, len, (unit_size + len - 1) / len);
	printf("prog_base = %I64d, unit_size = %d\n", prog_base, unit_size);
#endif

	// マルチ・スレッドの準備をする
	th->mat = factor;
	th->buf = buf;
	th->size = unit_size;
	th->count = read_num;
	th->off = try_cache_blocking(unit_size);	// キャッシュの最適化を試みる
	for (j = 0; j < cpu_num; j++){	// サブ・スレッドごとに
		hRun[j] = CreateEvent(NULL, FALSE, FALSE, NULL);	// Auto Reset にする
		if (hRun[j] == NULL){
			print_win32_err();
			printf("error, sub-thread\n");
			err = 1;
			goto error_end;
		}
		hEnd[j] = CreateEvent(NULL, TRUE, FALSE, NULL);
		if (hEnd[j] == NULL){
			print_win32_err();
			CloseHandle(hRun[j]);
			printf("error, sub-thread\n");
			err = 1;
			goto error_end;
		}
		// サブ・スレッドを起動する
		th->run = hRun[j];
		th->end = hEnd[j];
		th->now = j;	// スレッド番号
		//_mm_sfence();	// メモリーへの書き込みを完了してからスレッドを起動する
		hSub[j] = (HANDLE)_beginthreadex(NULL, STACK_SIZE, thread_encode3_single, (LPVOID)th, 0, NULL);
		if (hSub[j] == NULL){
			print_win32_err();
			CloseHandle(hRun[j]);
			CloseHandle(hEnd[j]);
			printf("error, sub-thread\n");
			err = 1;
			goto error_end;
		}
		WaitForSingleObject(hEnd[j], INFINITE);	// 設定終了の合図を待つ (リセットしない)
	}
	// IO が延滞しないように、サブ・スレッド一つの優先度を下げる
	SetThreadPriority(hSub[0], THREAD_PRIORITY_BELOW_NORMAL);

	// 何回かに別けてソース・ブロックを読み込んで、パリティ・ブロックを少しずつ作成する
	time_last = GetTickCount();
	wcscpy(file_path, base_dir);
	last_file = -1;
	source_off = 0;	// 読み込み開始スライス番号
	while (source_off < source_num){
		if (read_num > source_num - source_off)
			read_num = source_num - source_off;
		th->buf = NULL;
		th->count = source_off;
		th->off = -1;	// まだ計算して無い印

#ifdef TIMER
time_start = GetTickCount();
#endif
		for (i = 0; i < read_num; i++){	// スライスを一個ずつ読み込んでメモリー上に配置していく
			// ソース・ブロックを読み込む
			if (s_blk[source_off + i].file != last_file){	// 別のファイルなら開く
				if (hFile){
					CloseHandle(hFile);	// 前のファイルを閉じる
					hFile = NULL;
					// チェックサム・パケットの MD5 を計算する
					memcpy(&packet_off, files[last_file].hash + 8, 4);
					memcpy(&len, files[last_file].hash + 12, 4);
					//printf("Checksum[%d], off = %d, size = %d\n", last_file, packet_off, len);
					Phmd5Begin(&blk_md_ctx);
					Phmd5Process(&blk_md_ctx, common_buf + packet_off + 32, 32 + len);
					Phmd5End(&blk_md_ctx);
					memcpy(common_buf + packet_off + 16, blk_md_ctx.hash, 16);
					// ファイルのハッシュ値の計算を終える
					Phmd5End(&file_md_ctx);
					memcpy(&packet_off, files[last_file].hash, 4);	// ハッシュ値の位置 = off + 64 + 16
					memcpy(&len, files[last_file].hash + 4, 4);
					//printf("File[%d], off = %d, size = %d\n", last_file, packet_off, len);
					// ファイルのハッシュ値を書き込んでから、パケットの MD5 を計算する
					memcpy(common_buf + packet_off + 64 + 16, file_md_ctx.hash, 16);
					Phmd5Begin(&file_md_ctx);
					Phmd5Process(&file_md_ctx, common_buf + packet_off + 32, 32 + len);
					Phmd5End(&file_md_ctx);
					memcpy(common_buf + packet_off + 16, file_md_ctx.hash, 16);
				}
				last_file = s_blk[source_off + i].file;
				wcscpy(file_path + base_len, list_buf + files[last_file].name);
				// 1-pass方式なら、断片化しないので FILE_FLAG_SEQUENTIAL_SCAN を付けた方がいいかも
				hFile = CreateFile(file_path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);
				if (hFile == INVALID_HANDLE_VALUE){
					print_win32_err();
					hFile = NULL;
					printf_cp("cannot open file, %s\n", list_buf + files[last_file].name);
					err = 1;
					goto error_end;
				}
				// ファイルのハッシュ値の計算を始める
				Phmd5Begin(&file_md_ctx);
				// チェックサムの位置 = off + 64 + 16
				memcpy(&packet_off, files[last_file].hash + 8, 4);
				packet_off += 64 + 16;
			}
			// バッファーにソース・ファイルの内容を読み込む
			len = s_blk[source_off + i].size;
			if (!ReadFile(hFile, buf + (size_t)unit_size * i, len, &j, NULL) || (len != j)){
				print_win32_err();
				err = 1;
				goto error_end;
			}
			if (len < block_size)
				memset(buf + ((size_t)unit_size * i + len), 0, block_size - len);
			// ファイルのハッシュ値を計算する
			Phmd5Process(&file_md_ctx, buf + (size_t)unit_size * i, len);
			// ソース・ブロックのチェックサムを計算する
			len = crc_update(0xFFFFFFFF, buf + (size_t)unit_size * i, block_size) ^ 0xFFFFFFFF;	// include pad
			Phmd5Begin(&blk_md_ctx);
			Phmd5Process(&blk_md_ctx, buf + (size_t)unit_size * i, block_size);
			Phmd5End(&blk_md_ctx);
			memcpy(common_buf + packet_off, blk_md_ctx.hash, 16);
			memcpy(common_buf + packet_off + 16, &len, 4);
			packet_off += 20;
			checksum16_altmap(buf + (size_t)unit_size * i, buf + ((size_t)unit_size * i + unit_size - HASH_SIZE), unit_size - HASH_SIZE);

			if (i + 1 < read_num){	// 最後のブロック以外なら
				// サブ・スレッドの動作状況を調べる
				j = WaitForMultipleObjects((cpu_num + 1) / 2, hEnd, TRUE, 0);
				if ((j != WAIT_TIMEOUT) && (j != WAIT_FAILED)){	// 計算中でないなら
					// 経過表示
					prog_num += parity_num;
					if (GetTickCount() - time_last >= UPDATE_TIME){
						if (print_progress((int)((prog_num * 1000) / prog_base))){
							err = 2;
							goto error_end;
						}
						time_last = GetTickCount();
					}
					// 計算終了したブロックの次から計算を開始する
					th->off += 1;
					for (j = 0; j < parity_num; j++)
						factor[j] = galois_power(constant[source_off + th->off], first_num + j);	// factor は定数行列の乗数になる
					th->now = -1;	// 初期値 - 1
					//_mm_sfence();	// メモリーへの書き込みを完了してからスレッドを再開する
					for (j = 0; j < (cpu_num + 1) / 2; j++){	// 読み込み中はスレッド数を減らす
						ResetEvent(hEnd[j]);	// リセットしておく
						SetEvent(hRun[j]);	// サブ・スレッドに計算を開始させる
					}
				}
			}
		}
		if (source_off + i == source_num){	// 最後のソース・ファイルを閉じる
			CloseHandle(hFile);
			hFile = NULL;
			// チェックサム・パケットの MD5 を計算する
			memcpy(&packet_off, files[last_file].hash + 8, 4);
			memcpy(&len, files[last_file].hash + 12, 4);
			//printf("Checksum[%d], off = %d, size = %d\n", last_file, packet_off, len);
			Phmd5Begin(&blk_md_ctx);
			Phmd5Process(&blk_md_ctx, common_buf + packet_off + 32, 32 + len);
			Phmd5End(&blk_md_ctx);
			memcpy(common_buf + packet_off + 16, blk_md_ctx.hash, 16);
			// ファイルのハッシュ値の計算を終える
			Phmd5End(&file_md_ctx);
			memcpy(&packet_off, files[last_file].hash, 4);	// ハッシュ値の位置 = off + 64 + 16
			memcpy(&len, files[last_file].hash + 4, 4);
			//printf("File[%d], off = %d, size = %d\n", last_file, packet_off, len);
			// ファイルのハッシュ値を書き込んでから、パケットの MD5 を計算する
			memcpy(common_buf + packet_off + 64 + 16, file_md_ctx.hash, 16);
			Phmd5Begin(&file_md_ctx);
			Phmd5Process(&file_md_ctx, common_buf + packet_off + 32, 32 + len);
			Phmd5End(&file_md_ctx);
			memcpy(common_buf + packet_off + 16, file_md_ctx.hash, 16);
		}
#ifdef TIMER
time_read += GetTickCount() - time_start;
#endif

		WaitForMultipleObjects((cpu_num + 1) / 2, hEnd, TRUE, INFINITE);	// サブ・スレッドの計算終了の合図を待つ
		th->off += 1;	// 計算を開始するソース・ブロックの番号
		if (source_off + th->off == 0)	// エラーや実験時以外は th->off は 0 にならない
			memset(p_buf, 0, (size_t)unit_size * parity_num);
#ifdef TIMER
		j = (th->off * 1000) / read_num;
		printf("partial encode = %d (%d.%d%%)\n", th->off, j / 10, j % 10);
		// ここまでのパリティ・ブロックのチェックサムを検証する
/*		for (j = 0; j < parity_num; j++){
			checksum16_return(p_buf + (size_t)unit_size * j, hash, unit_size - HASH_SIZE);
			if (memcmp(p_buf + ((size_t)unit_size * j + unit_size - HASH_SIZE), hash, HASH_SIZE) != 0){
				printf("checksum mismatch, recovery slice %d after 1st encode\n", j);
				err = 1;
				goto error_end;
			}
			galois_altmap_change(p_buf + (size_t)unit_size * j, unit_size);
		}*/
#endif

		// 経過表示
		prog_num += read_num - th->off;
		if (GetTickCount() - time_last >= UPDATE_TIME){
			if (print_progress((int)((prog_num * 1000) / prog_base))){
				err = 2;
				goto error_end;
			}
			time_last = GetTickCount();
		}

		// 最初のパリティの計算を始めておく
		work_buf = p_buf;
		th->count = read_num;
		for (j = 0; j < read_num; j++)
			factor[j] = galois_power(constant[source_off + j], first_num);	// factor は定数行列の乗数になる
		th->buf = work_buf;
		th->now = -1;	// 初期値 - 1
		//_mm_sfence();
		for (j = 0; j < cpu_num; j++){
			ResetEvent(hEnd[j]);	// リセットしておく
			SetEvent(hRun[j]);	// サブ・スレッドに計算を開始させる
		}

		// パリティ・ブロックごとに
		for (i = 0; i < parity_num; i++){
			// パリティの計算が終わるのを待って完成させる
			WaitForMultipleObjects(cpu_num, hEnd, TRUE, INFINITE);	// サブ・スレッドの計算終了の合図を待つ
			for (j = 1; j < cpu_num; j++){
				// 最後にサブ・スレッドのバッファーを XOR する
				galois_align_xor(sub_buf + (size_t)unit_size * (j - 1), work_buf, unit_size);
			}
			if (i + 1 < parity_num){	// 最後のブロック以外なら
				// 経過表示
				prog_num += read_num - th->off;
				if (GetTickCount() - time_last >= UPDATE_TIME){
					if (print_progress((int)((prog_num * 1000) / prog_base))){
						err = 2;
						goto error_end;
					}
					time_last = GetTickCount();
				}
				// 次のパリティの計算を開始しておく
				for (j = 0; j < read_num; j++)
					factor[j] = galois_power(constant[source_off + j], first_num + i + 1);	// factor は定数行列の乗数になる
				th->buf += unit_size;
				th->now = -1;	// 初期値 - 1
				//_mm_sfence();	// メモリーへの書き込みを完了してからスレッドを再開する
				for (j = 0; j < cpu_num; j++){
					ResetEvent(hEnd[j]);	// リセットしておく
					SetEvent(hRun[j]);	// サブ・スレッドに計算を開始させる
				}
			}

			work_buf += unit_size;
		}

		source_off += read_num;
	}
	//printf("\nprog_num = %I64d / %I64d\n", prog_num, prog_base);

#ifdef TIMER
time_start = GetTickCount();
#endif
	memcpy(common_buf + common_size, common_buf, common_size);	// 後の半分に前半のをコピーする
	// 最後にパリティ・ブロックのチェックサムを検証して、リカバリ・ファイルに書き込む
	err = create_recovery_file_1pass(file_path, recovery_path, packet_limit, block_distri,
			packet_num, common_buf, common_size, footer_buf, footer_size, rcv_hFile, p_buf, unit_size);
#ifdef TIMER
time_write = GetTickCount() - time_start;
#endif

#ifdef TIMER
printf("read   %d.%03d sec\n", time_read / 1000, time_read % 1000);
printf("write  %d.%03d sec\n", time_write / 1000, time_write % 1000);
#endif

error_end:
	InterlockedExchange(&(th->now), INT_MAX / 2);	// サブ・スレッドの計算を中断する
	for (j = 0; j < cpu_num; j++){
		if (hSub[j]){	// サブ・スレッドを終了させる
			SetEvent(hRun[j]);
			WaitForSingleObject(hSub[j], INFINITE);
			CloseHandle(hSub[j]);
		}
	}
	if (hFile)
		CloseHandle(hFile);
	if (buf)
		_aligned_free(buf);
	return err;
}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
// chunk ごとに並び替えるバージョン


// chunk ごとに並び替える
void arrange_copy(
	unsigned char *dst,
	unsigned char *src,
	unsigned int unit_size,
	int i,					// ソース・ブロックの番号
	int read_num,			// 読み込むソース・ブロックの数
	int chunk_num,
	size_t chunk_size)
{
	int j;
	size_t rest_size, chunk_range;

	chunk_range = chunk_size * read_num;
	for (j = 0; j < chunk_num - 1; j++)
		memcpy(dst + chunk_range * j + chunk_size * i, src + chunk_size * j, chunk_size);
	rest_size = unit_size - chunk_size * j;	// 最後の chunk だけサイズが異なる
	memcpy(dst + chunk_range * j + rest_size * i, src + chunk_size * j, rest_size);
}

void arrange_zero(
	unsigned char *dst,
	unsigned int unit_size,
	int i,					// ソース・ブロックの番号
	int read_num,			// 読み込むソース・ブロックの数
	int chunk_num,
	size_t chunk_size)
{
	int j;
	size_t rest_size, chunk_range;

	chunk_range = chunk_size * read_num;
	for (j = 0; j < chunk_num - 1; j++)
		memset(dst + chunk_range * j + chunk_size * i, 0, chunk_size);
	rest_size = unit_size - chunk_size * j;	// 最後の chunk だけサイズが異なる
	memset(dst + chunk_range * j + rest_size * i, 0, rest_size);
}


// chunk ごとに並び替える
void arrange_copy(
	unsigned char *dst,
	unsigned char *src,
	unsigned int unit_size,
	int i,					// ソース・ブロックの番号
	int read_num,			// 読み込むソース・ブロックの数
	int chunk_num,
	size_t chunk_size);

void arrange_zero(
	unsigned char *dst,
	unsigned int unit_size,
	int i,					// ソース・ブロックの番号
	int read_num,			// 読み込むソース・ブロックの数
	int chunk_num,
	size_t chunk_size);


// chunk ごとに並び替えて計算するためのスレッド
static DWORD WINAPI thread_encode2_arrange(LPVOID lpParameter)
{
	unsigned char *s_buf, *p_buf, *work_buf, *c_buf;
	unsigned short *constant, factor2;
	volatile unsigned short *factor1;
	int i, j, src_start, src_num, max_num;
	int chunk_num, part_start, part_num, cover_num;
	unsigned int unit_size, len, off, chunk_size;
	size_t chunk_range;
	HANDLE hRun, hEnd;
	RS_TH *th;
#ifdef TIMER
unsigned int loop_count2a = 0, loop_count2b = 0;
unsigned int time_start2, time_encode2a = 0, time_encode2b = 0;
#endif

	th = (RS_TH *)lpParameter;
	constant = th->mat;
	s_buf = th->buf;
	unit_size = th->size;
	chunk_size = th->off;
	part_num = th->count;
	hRun = th->run;
	hEnd = th->end;
	//_mm_sfence();
	SetEvent(hEnd);	// 設定完了を通知する

	factor1 = constant + source_num;
	chunk_range = (size_t)chunk_size * source_num;
	chunk_num = (unit_size + chunk_size - 1) / chunk_size;
	p_buf = s_buf + (size_t)unit_size * (source_num + 1);

	WaitForSingleObject(hRun, INFINITE);	// 計算開始の合図を待つ
	while (th->now < INT_MAX / 2){
#ifdef TIMER
time_start2 = GetTickCount();
#endif
		src_start = th->off;	// ソース・ブロック番号
		len = chunk_size;

		if (th->size == 0){	// ソース・ブロック読み込み中
			// パリティ・ブロックごとに掛け算して追加していく
			max_num = chunk_num * part_num;
			while ((j = InterlockedIncrement(&(th->now))) < max_num){	// j = ++th_now
				off = j / part_num;	// chunk の番号
				j = j % part_num;	// parity の番号
				c_buf = s_buf + chunk_range * off;
				off *= chunk_size;
				if (off + len > unit_size)
					len = unit_size - off;	// 最後の chunk だけサイズが異なるかも
				c_buf += (size_t)len * src_start;
				if (src_start == 0)	// 最初のブロックを計算する際に
					memset(p_buf + ((size_t)unit_size * j + off), 0, len);	// ブロックを 0で埋める
				galois_align_multiply(c_buf, p_buf + ((size_t)unit_size * j + off), len, factor1[j]);
#ifdef TIMER
loop_count2a++;
#endif
			}
#ifdef TIMER
time_encode2a += GetTickCount() - time_start2;
#endif
		} else {	// パリティ・ブロックを部分的に保持する場合
			// スレッドごとに作成するパリティ・ブロックの chunk を変える
			src_num = source_num - src_start;
			cover_num = th->size;
			part_start = th->count;
			max_num = chunk_num * cover_num;
			while ((j = InterlockedIncrement(&(th->now))) < max_num){	// j = ++th_now
				off = j / cover_num;	// chunk の番号
				j = j % cover_num;		// parity の番号
				c_buf = s_buf + chunk_range * off;	// source chunk の位置
				off *= chunk_size;		// parity chunk の位置
				if (off + len > unit_size)
					len = unit_size - off;	// 最後の chunk だけサイズが異なるかも
				c_buf += (size_t)len * src_start;
				work_buf = p_buf + (size_t)unit_size * j + off;
				if (part_start != 0)
					memset(work_buf, 0, len);	// 最初の part_num 以降は 2nd encode だけなので 0で埋める

				// ソース・ブロックごとにパリティを追加していく
				for (i = 0; i < src_num; i++){
					factor2 = galois_power(constant[src_start + i], first_num + part_start + j);	// factor は定数行列の乗数になる
					galois_align_multiply(c_buf + ((size_t)len * i), work_buf, len, factor2);
				}
#ifdef TIMER
loop_count2b += src_num;
#endif
			}
#ifdef TIMER
time_encode2b += GetTickCount() - time_start2;
#endif
		}
		//_mm_sfence();	// メモリーへの書き込みを完了する
		SetEvent(hEnd);	// 計算終了を通知する
		WaitForSingleObject(hRun, INFINITE);	// 計算開始の合図を待つ
	}
#ifdef TIMER
loop_count2a /= chunk_num;	// chunk数で割ってブロック数にする
loop_count2b /= chunk_num;
printf("sub-thread : total loop = %d\n", loop_count2a + loop_count2b);
if (time_encode2a > 0){
	i = (int)((__int64)loop_count2a * unit_size * 125 / ((__int64)time_encode2a * 131072));
} else {
	i = 0;
}
if (loop_count2a > 0)
	printf(" 1st encode %d.%03d sec, %d loop, %d MB/s\n", time_encode2a / 1000, time_encode2a % 1000, loop_count2a, i);
if (time_encode2b > 0){
	i = (int)((__int64)loop_count2b * unit_size * 125 / ((__int64)time_encode2b * 131072));
} else {
	i = 0;
}
printf(" 2nd encode %d.%03d sec, %d loop, %d MB/s\n", time_encode2b / 1000, time_encode2b % 1000, loop_count2b, i);
#endif

	// 終了処理
	CloseHandle(hRun);
	CloseHandle(hEnd);
	return 0;
}

static DWORD WINAPI thread_encode3_arrange(LPVOID lpParameter)
{
	unsigned char *s_buf, *p_buf, *work_buf, *c_buf;
	unsigned short *constant, factor2;
	volatile unsigned short *factor1;
	int i, j, src_start, src_num, max_num;
	int chunk_num, source_off, read_num;
	unsigned int unit_size, len, off, chunk_size;
	size_t chunk_range;
	HANDLE hRun, hEnd;
	RS_TH *th;
#ifdef TIMER
unsigned int loop_count2a = 0, loop_count2b = 0;
unsigned int time_start2, time_encode2a = 0, time_encode2b = 0;
#endif

	th = (RS_TH *)lpParameter;
	constant = th->mat;
	s_buf = th->buf;
	unit_size = th->size;
	read_num = th->count;
	chunk_size = th->off;
	hRun = th->run;
	hEnd = th->end;
	//_mm_sfence();
	SetEvent(hEnd);	// 設定完了を通知する

	factor1 = constant + source_num;
	chunk_num = (unit_size + chunk_size - 1) / chunk_size;
	max_num = chunk_num * parity_num;
	p_buf = s_buf + (size_t)unit_size * (read_num + 1);

	WaitForSingleObject(hRun, INFINITE);	// 計算開始の合図を待つ
	while (th->now < INT_MAX / 2){
#ifdef TIMER
time_start2 = GetTickCount();
#endif
		source_off = (th->count) >> 16;
		read_num = (th->count) & 0xFFFF;
		src_start = th->off;	// ソース・ブロック番号
		len = chunk_size;
		chunk_range = (size_t)chunk_size * read_num;

		if (th->size == 0){	// ソース・ブロック読み込み中
			// パリティ・ブロックごとに掛け算して追加していく
			while ((j = InterlockedIncrement(&(th->now))) < max_num){	// j = ++th_now
				off = j / parity_num;	// chunk の番号
				j = j % parity_num;		// parity の番号
				c_buf = s_buf + chunk_range * off;
				off *= chunk_size;
				if (off + len > unit_size)
					len = unit_size - off;	// 最後の chunk だけサイズが異なるかも
				c_buf += (size_t)len * (src_start - source_off);
				if (src_start == 0)	// 最初のブロックを計算する際に
					memset(p_buf + ((size_t)unit_size * j + off), 0, len);	// ブロックを 0で埋める
				galois_align_multiply(c_buf, p_buf + ((size_t)unit_size * j + off), len, factor1[j]);
#ifdef TIMER
loop_count2a++;
#endif
			}
#ifdef TIMER
time_encode2a += GetTickCount() - time_start2;
#endif
		} else {	// 全てのパリティ・ブロックを保持する場合
			// スレッドごとに作成するパリティ・ブロックの chunk を変える
			src_num = th->size;
			while ((j = InterlockedIncrement(&(th->now))) < max_num){	// j = ++th_now
				off = j / parity_num;	// chunk の番号
				j = j % parity_num;		// parity の番号
				c_buf = s_buf + chunk_range * off;	// source chunk の位置
				off *= chunk_size;		// parity chunk の位置
				if (off + len > unit_size)
					len = unit_size - off;	// 最後の chunk だけサイズが異なるかも
				c_buf += (size_t)len * (src_start - source_off);
				work_buf = p_buf + (size_t)unit_size * j + off;

				// ソース・ブロックごとにパリティを追加していく
				for (i = 0; i < src_num; i++){
					factor2 = galois_power(constant[src_start + i], first_num + j);	// factor は定数行列の乗数になる
					galois_align_multiply(c_buf + ((size_t)len * i), work_buf, len, factor2);
				}
#ifdef TIMER
loop_count2b += src_num;
#endif
			}
#ifdef TIMER
time_encode2b += GetTickCount() - time_start2;
#endif
		}
		//_mm_sfence();	// メモリーへの書き込みを完了する
		SetEvent(hEnd);	// 計算終了を通知する
		WaitForSingleObject(hRun, INFINITE);	// 計算開始の合図を待つ
	}
#ifdef TIMER
loop_count2a /= chunk_num;	// chunk数で割ってブロック数にする
loop_count2b /= chunk_num;
printf("sub-thread : total loop = %d\n", loop_count2a + loop_count2b);
if (time_encode2a > 0){
	i = (int)((__int64)loop_count2a * unit_size * 125 / ((__int64)time_encode2a * 131072));
} else {
	i = 0;
}
if (loop_count2a > 0)
	printf(" 1st encode %d.%03d sec, %d loop, %d MB/s\n", time_encode2a / 1000, time_encode2a % 1000, loop_count2a, i);
if (time_encode2b > 0){
	i = (int)((__int64)loop_count2b * unit_size * 125 / ((__int64)time_encode2b * 131072));
} else {
	i = 0;
}
printf(" 2nd encode %d.%03d sec, %d loop, %d MB/s\n", time_encode2b / 1000, time_encode2b % 1000, loop_count2b, i);
#endif

	// 終了処理
	CloseHandle(hRun);
	CloseHandle(hEnd);
	return 0;
}


int encode_method2_arrange(	// ソース・データを全て読み込む場合 (chunkごとに並び替える)
	wchar_t *file_path,
	unsigned char *header_buf,	// Recovery Slice packet のパケット・ヘッダー
	HANDLE *rcv_hFile,			// リカバリ・ファイルのハンドル
	file_ctx_c *files,			// ソース・ファイルの情報
	source_ctx_c *s_blk,		// ソース・ブロックの情報
	parity_ctx_c *p_blk,		// パリティ・ブロックの情報
	unsigned short *constant)	// 複数ブロック分の領域を確保しておく？
{
	unsigned char *buf = NULL, *p_buf, *work_buf, *read_buf, *hash;
	unsigned short *factor1;
	int err = 0, i, j, last_file, part_start, part_num;
	int src_num, chunk_num, cover_num;
	unsigned int io_size, unit_size, len, block_off, chunk_size;
	unsigned int time_last, prog_write;
	__int64 file_off, prog_num = 0, prog_base;
	HANDLE hFile = NULL;
	HANDLE hSub[MAX_CPU], hRun[MAX_CPU], hEnd[MAX_CPU];
	RS_TH th[1];
	PHMD5 md_ctx, *md_ptr = NULL;

	memset(hSub, 0, sizeof(HANDLE) * MAX_CPU);
	factor1 = constant + source_num;

	// 作業バッファーを確保する（読み込み用に1個多くする）
	part_num = source_num >> PART_MAX_RATE;	// ソース・ブロック数に対する割合で最大量を決める
	//part_num = (parity_num + 1) / 2;	// 確保量の実験用
	//part_num = (parity_num + 2) / 3;	// 確保量の実験用
	if (part_num < parity_num){	// 分割して計算するなら
		i = (parity_num + part_num - 1) / part_num;	// 分割回数
		part_num = (parity_num + i - 1) / i;
		part_num = ((part_num + cpu_num - 1) / cpu_num) * cpu_num;	// cpu_num の倍数にする（切り上げ）
	}
	if (part_num > parity_num)
		part_num = parity_num;
	io_size = get_io_size(source_num + 1, &part_num, 1, sse_unit);
	//io_size = (((io_size + 1) / 2 + HASH_SIZE + (sse_unit - 1)) & ~(sse_unit - 1)) - HASH_SIZE;	// 2分割の実験用
	//io_size = (((io_size + 2) / 3 + HASH_SIZE + (sse_unit - 1)) & ~(sse_unit - 1)) - HASH_SIZE;	// 3分割の実験用
	unit_size = io_size + HASH_SIZE;	// チェックサムの分だけ増やす
	file_off = (source_num + 1 + part_num) * (size_t)unit_size + HASH_SIZE;
	buf = _aligned_malloc((size_t)file_off, sse_unit);
	if (buf == NULL){
		printf("malloc, %I64d\n", file_off);
		err = 1;
		goto error_end;
	}
	read_buf = buf + (size_t)unit_size * source_num;
	p_buf = read_buf + unit_size;	// パリティ・ブロックを部分的に記録する領域
	hash = p_buf + (size_t)unit_size * part_num;
	prog_base = (block_size + io_size - 1) / io_size;
	prog_write = source_num >> 5;	// 計算で 97%、書き込みで 3% ぐらい
	if (prog_write == 0)
		prog_write = 1;
	prog_base *= (__int64)(source_num + prog_write) * parity_num;	// 全体の断片の個数
	chunk_size = try_cache_blocking(unit_size);
	//chunk_size = ((chunk_size + 2) / 3 + (sse_unit - 1)) & ~(sse_unit - 1);	// 1/3の実験用
	chunk_num = (unit_size + chunk_size - 1) / chunk_size;
#ifdef TIMER
	printf("\n read all source blocks, and keep some parity blocks (arrange)\n");
	printf("buffer size = %I64d MB, io_size = %d, split = %d\n", file_off >> 20, io_size, (block_size + io_size - 1) / io_size);
	printf("cache: limit size = %d, chunk_size = %d, split = %d\n", cpu_cache & 0x7FFF8000, chunk_size, chunk_num);
	printf("prog_base = %I64d, unit_size = %d, part_num = %d\n", prog_base, unit_size, part_num);
#endif

	if (io_size < block_size){	// スライスが分割される場合だけ、途中までのハッシュ値を保持する
		block_off = sizeof(PHMD5) * parity_num;
		md_ptr = malloc(block_off);
		if (md_ptr == NULL){
			printf("malloc, %d\n", block_off);
			err = 1;
			goto error_end;
		}
		for (i = 0; i < parity_num; i++){
			Phmd5Begin(&(md_ptr[i]));
			j = first_num + i;	// 最初の番号の分だけ足す
			memcpy(header_buf + 64, &j, 4);	// Recovery Slice の番号を書き込む
			Phmd5Process(&(md_ptr[i]), header_buf + 32, 36);
		}
	}

	// マルチ・スレッドの準備をする
	th->mat = constant;
	th->buf = buf;
	th->size = unit_size;
	th->count = part_num;
	th->off = chunk_size;	// キャッシュの最適化を試みる
	for (j = 0; j < cpu_num; j++){	// サブ・スレッドごとに
		hRun[j] = CreateEvent(NULL, FALSE, FALSE, NULL);	// Auto Reset にする
		if (hRun[j] == NULL){
			print_win32_err();
			printf("error, sub-thread\n");
			err = 1;
			goto error_end;
		}
		hEnd[j] = CreateEvent(NULL, TRUE, FALSE, NULL);
		if (hEnd[j] == NULL){
			print_win32_err();
			CloseHandle(hRun[j]);
			printf("error, sub-thread\n");
			err = 1;
			goto error_end;
		}
		// サブ・スレッドを起動する
		th->run = hRun[j];
		th->end = hEnd[j];
		//_mm_sfence();	// メモリーへの書き込みを完了してからスレッドを起動する
		hSub[j] = (HANDLE)_beginthreadex(NULL, STACK_SIZE, thread_encode2_arrange, (LPVOID)th, 0, NULL);
		if (hSub[j] == NULL){
			print_win32_err();
			CloseHandle(hRun[j]);
			CloseHandle(hEnd[j]);
			printf("error, sub-thread\n");
			err = 1;
			goto error_end;
		}
		WaitForSingleObject(hEnd[j], INFINITE);	// 設定終了の合図を待つ (リセットしない)
	}
	// IO が延滞しないように、サブ・スレッド一つの優先度を下げる
	SetThreadPriority(hSub[0], THREAD_PRIORITY_BELOW_NORMAL);

	// ソース・ブロック断片を読み込んで、パリティ・ブロック断片を作成する
	time_last = GetTickCount();
	wcscpy(file_path, base_dir);
	block_off = 0;
	while (block_off < block_size){
		th->size = 0;	// 1st encode
		th->off = -1;	// まだ計算して無い印

		// ソース・ブロックを読み込む
#ifdef TIMER
read_count = 0;
skip_count = 0;
time_start = GetTickCount();
#endif
		last_file = -1;
		for (i = 0; i < source_num; i++){
			if (s_blk[i].file != last_file){	// 別のファイルなら開く
				last_file = s_blk[i].file;
				if (hFile){
					CloseHandle(hFile);	// 前のファイルを閉じる
					hFile = NULL;
				}
				wcscpy(file_path + base_len, list_buf + files[last_file].name);
				hFile = CreateFile(file_path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
				if (hFile == INVALID_HANDLE_VALUE){
					print_win32_err();
					hFile = NULL;
					printf_cp("cannot open file, %s\n", list_buf + files[last_file].name);
					err = 1;
					goto error_end;
				}
				file_off = block_off;
			} else {	// 同じファイルならブロック・サイズ分ずらす
				file_off += block_size;
			}
			if (s_blk[i].size > block_off){	// バッファーにソース・ファイルの内容を読み込む
				len = s_blk[i].size - block_off;
				if (len > io_size)
					len = io_size;
				if (file_read_data(hFile, file_off, read_buf, len)){
					printf("file_read_data, input slice %d\n", i);
					err = 1;
					goto error_end;
				}
				if (len < io_size)
					memset(read_buf + len, 0, io_size - len);
				// ソース・ブロックのチェックサムを計算する
				if (block_off == 0)
					s_blk[i].crc = 0xFFFFFFFF;
				s_blk[i].crc = crc_update(s_blk[i].crc, read_buf, len);	// without pad
				checksum16_altmap(read_buf, read_buf + io_size, io_size);
				// chunk ごとに並び替える
				arrange_copy(buf, read_buf, unit_size, i, source_num, chunk_num, chunk_size);
#ifdef TIMER
read_count++;
#endif

				if (i + 1 < source_num){	// 最後のブロック以外なら
					// サブ・スレッドの動作状況を調べる
					j = WaitForMultipleObjects((cpu_num + 1) / 2, hEnd, TRUE, 0);
					if ((j != WAIT_TIMEOUT) && (j != WAIT_FAILED)){	// 計算中でないなら
						// 経過表示
						prog_num += part_num;
						if (GetTickCount() - time_last >= UPDATE_TIME){
							if (print_progress((int)((prog_num * 1000) / prog_base))){
								err = 2;
								goto error_end;
							}
							time_last = GetTickCount();
						}
						// 計算終了したブロックの次から計算を開始する
						th->off += 1;
						if (th->off > 0){	// バッファーに読み込んだ時だけ計算する
							while (s_blk[th->off].size <= block_off){
								prog_num += part_num;
								th->off += 1;
#ifdef TIMER
skip_count++;
#endif
							}
						}
						for (j = 0; j < part_num; j++)
							factor1[j] = galois_power(constant[th->off], first_num + j);	// factor は定数行列の乗数になる
						th->now = -1;	// 初期値 - 1
						//_mm_sfence();
						for (j = 0; j < (cpu_num + 1) / 2; j++){
							ResetEvent(hEnd[j]);	// リセットしておく
							SetEvent(hRun[j]);	// サブ・スレッドに計算を開始させる
						}
					}
				}
			} else {
				arrange_zero(buf, unit_size, i, source_num, chunk_num, chunk_size);	// 0 で埋める所も chunk ごとにする
			}
		}
		// 最後のソース・ファイルを閉じる
		CloseHandle(hFile);
		hFile = NULL;
#ifdef TIMER
time_read += GetTickCount() - time_start;
#endif

		WaitForMultipleObjects((cpu_num + 1) / 2, hEnd, TRUE, INFINITE);	// サブ・スレッドの計算終了の合図を待つ
		th->off += 1;	// 計算を開始するソース・ブロックの番号
		if (th->off > 0){
			while (s_blk[th->off].size <= block_off){	// 計算不要なソース・ブロックはとばす
				prog_num += part_num;
				th->off += 1;
#ifdef TIMER
skip_count++;
#endif
			}
		} else {	// エラーや実験時以外は th->off は 0 にならない
			memset(p_buf, 0, (size_t)unit_size * part_num);
		}
#ifdef TIMER
		j = (th->off * 1000) / source_num;
		printf("partial encode = %d / %d (%d.%d%%), read = %d, skip = %d\n", th->off, source_num, j / 10, j % 10, read_count, skip_count);
		// ここまでのパリティ・ブロックのチェックサムを検証する
/*		if (th->off > 0){
			for (j = 0; j < part_num; j++){
				checksum16_return(p_buf + (size_t)unit_size * j, hash, io_size);
				if (memcmp(p_buf + ((size_t)unit_size * j + io_size), hash, HASH_SIZE) != 0){
					printf("checksum mismatch, recovery slice %d after 1st encode\n", j);
					err = 1;
					goto error_end;
				}
				galois_altmap_change(p_buf + (size_t)unit_size * j, unit_size);
			}
		}*/
#endif

		// リカバリ・ファイルに書き込むサイズ
		if (block_size - block_off < io_size){
			len = block_size - block_off;
		} else {
			len = io_size;
		}

		// cover_num ごとに処理する
		part_start = 0;
		cover_num = part_num;	// part_num は cpu_num の倍数にすること
		src_num = source_num - th->off;	// 一度に処理する量 (src_num > 0)
		while (part_start < parity_num){
			if (part_start == part_num){	// part_num 分の計算が終わったら
				th->off = 0;	// 最初の計算以降は全てのソース・ブロックを対象にする
				src_num = source_num;	// source_num - th->off
			}
			if (part_start + cover_num > parity_num)
				cover_num = parity_num - part_start;
			//printf("part_start = %d, src_num = %d / %d, cover_num = %d\n", part_start, src_num, source_num, cover_num);

			// スレッドごとにパリティ・ブロックを計算する
			th->size = cover_num;
			th->count = part_start;
			th->now = -1;	// 初期値 - 1
			//_mm_sfence();
			for (j = 0; j < cpu_num; j++){
				ResetEvent(hEnd[j]);	// リセットしておく
				SetEvent(hRun[j]);	// サブ・スレッドに計算を開始させる
			}

			// サブ・スレッドの計算終了の合図を UPDATE_TIME だけ待ちながら、経過表示する
			while (WaitForMultipleObjects(cpu_num, hEnd, TRUE, UPDATE_TIME) == WAIT_TIMEOUT){
				// th-now が最高値なので、計算が終わってるのは th-now - cpu_num 個となる
				j = th->now - cpu_num;
				if (j < 0)
					j = 0;
				j /= chunk_num;	// chunk数で割ってブロック数にする
				// 経過表示（UPDATE_TIME 時間待った場合なので、必ず経過してるはず）
				if (print_progress((int)(((prog_num + src_num * j) * 1000) / prog_base))){
					err = 2;
					goto error_end;
				}
				time_last = GetTickCount();
			}
			prog_num += src_num * cover_num;

#ifdef TIMER
time_start = GetTickCount();
#endif
			// パリティ・ブロックを書き込む
			work_buf = p_buf;
			for (i = part_start; i < part_start + cover_num; i++){
				// パリティ・ブロックのチェックサムを検証する
				checksum16_return(work_buf, hash, io_size);
				if (memcmp(work_buf + io_size, hash, HASH_SIZE) != 0){
					printf("checksum mismatch, recovery slice %d\n", i);
					err = 1;
					goto error_end;
				}
				// ハッシュ値を計算して、リカバリ・ファイルに書き込む
				if (io_size >= block_size){	// 1回で書き込みが終わるなら
					Phmd5Begin(&md_ctx);
					j = first_num + i;	// 最初の番号の分だけ足す
					memcpy(header_buf + 64, &j, 4);	// Recovery Slice の番号を書き込む
					Phmd5Process(&md_ctx, header_buf + 32, 36);
					Phmd5Process(&md_ctx, work_buf, len);
					Phmd5End(&md_ctx);
					memcpy(header_buf + 16, md_ctx.hash, 16);
					// ヘッダーを書き込む
					if (file_write_data(rcv_hFile[p_blk[i].file], p_blk[i].off + block_off - 68, header_buf, 68)){
						printf("file_write_data, recovery slice %d\n", i);
						err = 1;
						goto error_end;
					}
				} else {
					Phmd5Process(&(md_ptr[i]), work_buf, len);
				}
				//printf("%d, buf = %p, size = %u, off = %I64d\n", i, work_buf, len, p_blk[i].off + block_off);
				if (file_write_data(rcv_hFile[p_blk[i].file], p_blk[i].off + block_off, work_buf, len)){
					printf("file_write_data, recovery slice %d\n", i);
					err = 1;
					goto error_end;
				}
				work_buf += unit_size;

				// 経過表示
				prog_num += prog_write;
				if (GetTickCount() - time_last >= UPDATE_TIME){
					if (print_progress((int)((prog_num * 1000) / prog_base))){
						err = 2;
						goto error_end;
					}
					time_last = GetTickCount();
				}
			}
#ifdef TIMER
time_write += GetTickCount() - time_start;
#endif

			part_start += part_num;	// 次のパリティ位置にする
		}

		block_off += io_size;
	}
	print_progress_done();	// 改行して行の先頭に戻しておく
	//printf("prog_num = %I64d / %I64d\n", prog_num, prog_base);

	// ファイルごとにブロックの CRC-32 を検証する
	memset(buf, 0, io_size);
	j = 0;
	while (j < source_num){
		last_file = s_blk[j].file;
		src_num = (int)((files[last_file].size + (__int64)block_size - 1) / block_size);
		i = j + src_num - 1;	// 末尾ブロックの番号
		if (s_blk[i].size < block_size){	// 残りを 0 でパディングする
			len = block_size - s_blk[i].size;
			while (len > io_size){
				len -= io_size;
				s_blk[i].crc = crc_update(s_blk[i].crc, buf, io_size);
			}
			s_blk[i].crc = crc_update(s_blk[i].crc, buf, len);
		}
		memset(hash, 0, 16);
		for (i = 0; i < src_num; i++)	// XOR して 16バイトに減らす
			((unsigned int *)hash)[i & 3] ^= s_blk[j + i].crc ^ 0xFFFFFFFF;
		if (memcmp(files[last_file].hash, hash, 16) != 0){
			printf("checksum mismatch, input file %d\n", last_file);
			err = 1;
			goto error_end;
		}
		j += src_num;
	}

	//printf("io_size = %d, block_size = %d\n", io_size, block_size);
	if (io_size < block_size){	// 1回で書き込みが終わらなかったなら
		if (GetTickCount() - time_last >= UPDATE_TIME){	// キャンセルを受け付ける
			if (cancel_progress()){
				err = 2;
				goto error_end;
			}
		}

#ifdef TIMER
time_start = GetTickCount();
#endif
		// 最後に Recovery Slice packet のヘッダーを書き込む
		for (i = 0; i < parity_num; i++){
			Phmd5End(&(md_ptr[i]));
			memcpy(header_buf + 16, md_ptr[i].hash, 16);
			j = first_num + i;	// 最初のパリティ・ブロック番号の分だけ足す
			memcpy(header_buf + 64, &j, 4);	// Recovery Slice の番号を書き込む
			// リカバリ・ファイルに書き込む
			if (file_write_data(rcv_hFile[p_blk[i].file], p_blk[i].off - 68, header_buf, 68)){	// ヘッダーのサイズ分だけずらす
				printf("file_write_data, packet header\n");
				err = 1;
				goto error_end;
			}
		}
#ifdef TIMER
time_write += GetTickCount() - time_start;
#endif
	}

#ifdef TIMER
printf("read   %d.%03d sec\n", time_read / 1000, time_read % 1000);
printf("write  %d.%03d sec\n", time_write / 1000, time_write % 1000);
#endif

error_end:
	InterlockedExchange(&(th->now), INT_MAX / 2);	// サブ・スレッドの計算を中断する
	for (j = 0; j < cpu_num; j++){
		if (hSub[j]){	// サブ・スレッドを終了させる
			SetEvent(hRun[j]);
			WaitForSingleObject(hSub[j], INFINITE);
			CloseHandle(hSub[j]);
		}
	}
	if (md_ptr)
		free(md_ptr);
	if (hFile)
		CloseHandle(hFile);
	if (buf)
		_aligned_free(buf);
	return err;
}

int encode_method3_arrange(	// パリティ・ブロックを全て保持して、一度に書き込む場合 (chunkごとに並び替える)
	wchar_t *file_path,
	wchar_t *recovery_path,		// 作業用
	int packet_limit,			// リカバリ・ファイルのパケット繰り返しの制限
	int block_distri,			// パリティ・ブロックの分配方法 (3-bit目は番号の付け方)
	int packet_num,				// 共通パケットの数
	unsigned char *common_buf,	// 共通パケットのバッファー
	int common_size,			// 共通パケットのバッファー・サイズ
	unsigned char *footer_buf,	// 末尾パケットのバッファー
	int footer_size,			// 末尾パケットのバッファー・サイズ
	HANDLE *rcv_hFile,			// リカバリ・ファイルのハンドル
	file_ctx_c *files,			// ソース・ファイルの情報
	source_ctx_c *s_blk,		// ソース・ブロックの情報
	unsigned short *constant)
{
	unsigned char *buf = NULL, *p_buf, *read_buf;
	unsigned short *factor1;
	int err = 0, i, j, last_file, source_off, read_num, packet_off;
	int src_num, chunk_num;
	unsigned int unit_size, len, chunk_size;
	unsigned int time_last, prog_write;
	__int64 prog_num = 0, prog_base;
	size_t mem_size;
	HANDLE hFile = NULL;
	HANDLE hSub[MAX_CPU], hRun[MAX_CPU], hEnd[MAX_CPU];
	RS_TH th[1];
	PHMD5 file_md_ctx, blk_md_ctx;

	memset(hSub, 0, sizeof(HANDLE) * MAX_CPU);
	factor1 = constant + source_num;
	unit_size = (block_size + HASH_SIZE + (sse_unit - 1)) & ~(sse_unit - 1);	// チェックサムの分だけ増やす

	// 作業バッファーを確保する（読み込み用に1個多くする）
	read_num = read_block_num(parity_num, 1, 1, sse_unit);	// ソース・ブロックを何個読み込むか
	if (read_num == 0){
#ifdef TIMER
		printf("cannot keep enough blocks, use another method\n");
#endif
		return -2;	// スライスを分割して処理しないと無理
	}
	print_progress_text(0, "Creating recovery slice");
	//read_num = (read_num + 1) / 2 + 1;	// 2分割の実験用
	//read_num = (read_num + 2) / 3 + 1;	// 3分割の実験用
	mem_size = (size_t)(read_num + 1 + parity_num) * unit_size;
	buf = _aligned_malloc(mem_size, sse_unit);
	if (buf == NULL){
		printf("malloc, %Id\n", mem_size);
		err = 1;
		goto error_end;
	}
	read_buf = buf + (size_t)unit_size * read_num;
	p_buf = read_buf + unit_size;	// パリティ・ブロックを記録する領域
	prog_write = source_num >> 5;	// 計算で 97%、書き込みで 3% ぐらい
	if (prog_write == 0)
		prog_write = 1;
	prog_base = (__int64)(source_num + prog_write) * parity_num;	// ブロックの合計掛け算個数 + 書き込み回数
	chunk_size = try_cache_blocking(unit_size);
	chunk_num = (unit_size + chunk_size - 1) / chunk_size;
#ifdef TIMER
	printf("\n read some source blocks, and keep all parity blocks (arrange)\n");
	printf("buffer size = %Id MB, read_num = %d, round = %d\n", mem_size >> 20, read_num, (source_num + read_num - 1) / read_num);
	printf("cache: limit size = %d, chunk_size = %d, split = %d\n", cpu_cache & 0x7FFF8000, chunk_size, chunk_num);
	printf("prog_base = %I64d, unit_size = %d\n", prog_base, unit_size);
#endif

	// マルチ・スレッドの準備をする
	th->mat = constant;
	th->buf = buf;
	th->size = unit_size;
	th->count = read_num;
	th->off = chunk_size;	// キャッシュの最適化を試みる
	for (j = 0; j < cpu_num; j++){	// サブ・スレッドごとに
		hRun[j] = CreateEvent(NULL, FALSE, FALSE, NULL);	// Auto Reset にする
		if (hRun[j] == NULL){
			print_win32_err();
			printf("error, sub-thread\n");
			err = 1;
			goto error_end;
		}
		hEnd[j] = CreateEvent(NULL, TRUE, FALSE, NULL);
		if (hEnd[j] == NULL){
			print_win32_err();
			CloseHandle(hRun[j]);
			printf("error, sub-thread\n");
			err = 1;
			goto error_end;
		}
		// サブ・スレッドを起動する
		th->run = hRun[j];
		th->end = hEnd[j];
		//_mm_sfence();	// メモリーへの書き込みを完了してからスレッドを起動する
		hSub[j] = (HANDLE)_beginthreadex(NULL, STACK_SIZE, thread_encode3_arrange, (LPVOID)th, 0, NULL);
		if (hSub[j] == NULL){
			print_win32_err();
			CloseHandle(hRun[j]);
			CloseHandle(hEnd[j]);
			printf("error, sub-thread\n");
			err = 1;
			goto error_end;
		}
		WaitForSingleObject(hEnd[j], INFINITE);	// 設定終了の合図を待つ (リセットしない)
	}
	// IO が延滞しないように、サブ・スレッド一つの優先度を下げる
	SetThreadPriority(hSub[0], THREAD_PRIORITY_BELOW_NORMAL);

	// 何回かに別けてソース・ブロックを読み込んで、パリティ・ブロックを少しずつ作成する
	time_last = GetTickCount();
	wcscpy(file_path, base_dir);
	last_file = -1;
	source_off = 0;	// 読み込み開始スライス番号
	while (source_off < source_num){
		if (read_num > source_num - source_off)
			read_num = source_num - source_off;
		th->size = 0;	// 1st encode
		th->count = (source_off << 16) | read_num;
		th->off = source_off - 1;	// まだ計算して無い印

#ifdef TIMER
time_start = GetTickCount();
#endif
		for (i = 0; i < read_num; i++){	// スライスを一個ずつ読み込んでメモリー上に配置していく
			// ソース・ブロックを読み込む
			if (s_blk[source_off + i].file != last_file){	// 別のファイルなら開く
				if (hFile){
					CloseHandle(hFile);	// 前のファイルを閉じる
					hFile = NULL;
					// チェックサム・パケットの MD5 を計算する
					memcpy(&packet_off, files[last_file].hash + 8, 4);
					memcpy(&len, files[last_file].hash + 12, 4);
					//printf("Checksum[%d], off = %d, size = %d\n", last_file, packet_off, len);
					Phmd5Begin(&blk_md_ctx);
					Phmd5Process(&blk_md_ctx, common_buf + packet_off + 32, 32 + len);
					Phmd5End(&blk_md_ctx);
					memcpy(common_buf + packet_off + 16, blk_md_ctx.hash, 16);
					// ファイルのハッシュ値の計算を終える
					Phmd5End(&file_md_ctx);
					memcpy(&packet_off, files[last_file].hash, 4);	// ハッシュ値の位置 = off + 64 + 16
					memcpy(&len, files[last_file].hash + 4, 4);
					//printf("File[%d], off = %d, size = %d\n", last_file, packet_off, len);
					// ファイルのハッシュ値を書き込んでから、パケットの MD5 を計算する
					memcpy(common_buf + packet_off + 64 + 16, file_md_ctx.hash, 16);
					Phmd5Begin(&file_md_ctx);
					Phmd5Process(&file_md_ctx, common_buf + packet_off + 32, 32 + len);
					Phmd5End(&file_md_ctx);
					memcpy(common_buf + packet_off + 16, file_md_ctx.hash, 16);
				}
				last_file = s_blk[source_off + i].file;
				wcscpy(file_path + base_len, list_buf + files[last_file].name);
				// 1-pass方式なら、断片化しないので FILE_FLAG_SEQUENTIAL_SCAN を付けた方がいいかも
				hFile = CreateFile(file_path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);
				if (hFile == INVALID_HANDLE_VALUE){
					print_win32_err();
					hFile = NULL;
					printf_cp("cannot open file, %s\n", list_buf + files[last_file].name);
					err = 1;
					goto error_end;
				}
				// ファイルのハッシュ値の計算を始める
				Phmd5Begin(&file_md_ctx);
				// チェックサムの位置 = off + 64 + 16
				memcpy(&packet_off, files[last_file].hash + 8, 4);
				packet_off += 64 + 16;
			}
			// バッファーにソース・ファイルの内容を読み込む
			len = s_blk[source_off + i].size;
			if (!ReadFile(hFile, read_buf, len, &j, NULL) || (len != j)){
				print_win32_err();
				err = 1;
				goto error_end;
			}
			if (len < block_size)
				memset(read_buf + len, 0, block_size - len);
			// ファイルのハッシュ値を計算する
			Phmd5Process(&file_md_ctx, read_buf, len);
			// ソース・ブロックのチェックサムを計算する
			len = crc_update(0xFFFFFFFF, read_buf, block_size) ^ 0xFFFFFFFF;	// include pad
			Phmd5Begin(&blk_md_ctx);
			Phmd5Process(&blk_md_ctx, read_buf, block_size);
			Phmd5End(&blk_md_ctx);
			memcpy(common_buf + packet_off, blk_md_ctx.hash, 16);
			memcpy(common_buf + packet_off + 16, &len, 4);
			packet_off += 20;
			checksum16_altmap(read_buf, read_buf + unit_size - HASH_SIZE, unit_size - HASH_SIZE);
			// chunk ごとに並び替える
			arrange_copy(buf, read_buf, unit_size, i, read_num, chunk_num, chunk_size);

			if (i + 1 < read_num){	// 最後のブロック以外なら
				// サブ・スレッドの動作状況を調べる
				j = WaitForMultipleObjects((cpu_num + 1) / 2, hEnd, TRUE, 0);
				if ((j != WAIT_TIMEOUT) && (j != WAIT_FAILED)){	// 計算中でないなら
					// 経過表示
					prog_num += parity_num;
					if (GetTickCount() - time_last >= UPDATE_TIME){
						if (print_progress((int)((prog_num * 1000) / prog_base))){
							err = 2;
							goto error_end;
						}
						time_last = GetTickCount();
					}
					// 計算終了したブロックの次から計算を開始する
					th->off += 1;
					for (j = 0; j < parity_num; j++)
						factor1[j] = galois_power(constant[th->off], first_num + j);	// factor は定数行列の乗数になる
					th->now = -1;	// 初期値 - 1
					//_mm_sfence();
					for (j = 0; j < (cpu_num + 1) / 2; j++){
						ResetEvent(hEnd[j]);	// リセットしておく
						SetEvent(hRun[j]);	// サブ・スレッドに計算を開始させる
					}
				}
			}
		}
		if (source_off + i == source_num){	// 最後のソース・ファイルを閉じる
			CloseHandle(hFile);
			hFile = NULL;
			// チェックサム・パケットの MD5 を計算する
			memcpy(&packet_off, files[last_file].hash + 8, 4);
			memcpy(&len, files[last_file].hash + 12, 4);
			//printf("Checksum[%d], off = %d, size = %d\n", last_file, packet_off, len);
			Phmd5Begin(&blk_md_ctx);
			Phmd5Process(&blk_md_ctx, common_buf + packet_off + 32, 32 + len);
			Phmd5End(&blk_md_ctx);
			memcpy(common_buf + packet_off + 16, blk_md_ctx.hash, 16);
			// ファイルのハッシュ値の計算を終える
			Phmd5End(&file_md_ctx);
			memcpy(&packet_off, files[last_file].hash, 4);	// ハッシュ値の位置 = off + 64 + 16
			memcpy(&len, files[last_file].hash + 4, 4);
			//printf("File[%d], off = %d, size = %d\n", last_file, packet_off, len);
			// ファイルのハッシュ値を書き込んでから、パケットの MD5 を計算する
			memcpy(common_buf + packet_off + 64 + 16, file_md_ctx.hash, 16);
			Phmd5Begin(&file_md_ctx);
			Phmd5Process(&file_md_ctx, common_buf + packet_off + 32, 32 + len);
			Phmd5End(&file_md_ctx);
			memcpy(common_buf + packet_off + 16, file_md_ctx.hash, 16);
		}
#ifdef TIMER
time_read += GetTickCount() - time_start;
#endif

		WaitForMultipleObjects((cpu_num + 1) / 2, hEnd, TRUE, INFINITE);	// サブ・スレッドの計算終了の合図を待つ
		th->off += 1;	// 計算を開始するソース・ブロックの番号
		if (th->off == 0)	// エラーや実験時以外は th->off は 0 にならない
			memset(p_buf, 0, (size_t)unit_size * parity_num);
#ifdef TIMER
		j = ((th->off - source_off) * 1000) / read_num;
		printf("partial encode = %d / %d (%d.%d%%), source_off = %d\n", th->off - source_off, read_num, j / 10, j % 10, source_off);
		// ここまでのパリティ・ブロックのチェックサムを検証する
/*		if (th->off - source_off > 0){
			__declspec( align(16) ) unsigned char hash[HASH_SIZE];
			for (j = 0; j < parity_num; j++){
				checksum16_return(p_buf + (size_t)unit_size * j, hash, unit_size - HASH_SIZE);
				if (memcmp(p_buf + ((size_t)unit_size * j + unit_size - HASH_SIZE), hash, HASH_SIZE) != 0){
					printf("checksum mismatch, recovery slice %d after 1st encode\n", j);
					err = 1;
					goto error_end;
				}
				galois_altmap_change(p_buf + (size_t)unit_size * j, unit_size);
			}
		}*/
#endif

		// スレッドごとにパリティ・ブロックを計算する
		src_num = read_num - (th->off - source_off);	// 一度に処理する量 (src_num > 0)
		// th->off はソース・ブロックの番号
		th->size = src_num;
		th->now = -1;	// 初期値 - 1
		//_mm_sfence();
		for (j = 0; j < cpu_num; j++){
			ResetEvent(hEnd[j]);	// リセットしておく
			SetEvent(hRun[j]);	// サブ・スレッドに計算を開始させる
		}

		// サブ・スレッドの計算終了の合図を UPDATE_TIME だけ待ちながら、経過表示する
		while (WaitForMultipleObjects(cpu_num, hEnd, TRUE, UPDATE_TIME) == WAIT_TIMEOUT){
			// th-now が最高値なので、計算が終わってるのは th-now - cpu_num 個となる
			j = th->now - cpu_num;
			if (j < 0)
				j = 0;
			j /= chunk_num;	// chunk数で割ってブロック数にする
			// 経過表示（UPDATE_TIME 時間待った場合なので、必ず経過してるはず）
			if (print_progress((int)(((prog_num + src_num * j) * 1000) / prog_base))){
				err = 2;
				goto error_end;
			}
			time_last = GetTickCount();
		}

		// 経過表示
		prog_num += src_num * parity_num;
		if (GetTickCount() - time_last >= UPDATE_TIME){
			if (print_progress((int)((prog_num * 1000) / prog_base))){
				err = 2;
				goto error_end;
			}
			time_last = GetTickCount();
		}

		source_off += read_num;
	}
	//printf("\nprog_num = %I64d / %I64d\n", prog_num, prog_base);

#ifdef TIMER
time_start = GetTickCount();
#endif
	memcpy(common_buf + common_size, common_buf, common_size);	// 後の半分に前半のをコピーする
	// 最後にパリティ・ブロックのチェックサムを検証して、リカバリ・ファイルに書き込む
	err = create_recovery_file_1pass(file_path, recovery_path, packet_limit, block_distri,
			packet_num, common_buf, common_size, footer_buf, footer_size, rcv_hFile, p_buf, unit_size);
#ifdef TIMER
time_write = GetTickCount() - time_start;
#endif

#ifdef TIMER
printf("read   %d.%03d sec\n", time_read / 1000, time_read % 1000);
printf("write  %d.%03d sec\n", time_write / 1000, time_write % 1000);
#endif

error_end:
	InterlockedExchange(&(th->now), INT_MAX / 2);	// サブ・スレッドの計算を中断する
	for (j = 0; j < cpu_num; j++){
		if (hSub[j]){	// サブ・スレッドを終了させる
			SetEvent(hRun[j]);
			WaitForSingleObject(hSub[j], INFINITE);
			CloseHandle(hSub[j]);
		}
	}
	if (hFile)
		CloseHandle(hFile);
	if (buf)
		_aligned_free(buf);
	return err;
}

