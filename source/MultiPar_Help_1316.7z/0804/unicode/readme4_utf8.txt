<html lang="zh">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<meta http-equiv="Content-Style-Type" content="text/css">
<style type="text/css">
<!--
*       {line-height:1.5;}
a       {text-decoration:none;}
a:hover {text-decoration:underline;}
-->
</style>
<title>导言 - 支持</title>
</head>
<body>
<h3>许可证</h3>
<p>&nbsp
MultiPar由PAR客户端和用于控制它们的图形用户界面（GUI）组成，由Yutaka Sawada编写。尽管控制台应用程序是开源的（PAR客户端采用GPL协议），但GUI程序是闭源的。有些文章可以在<a href="http://hp.vector.co.jp/authors/VA021385/" target="_blank" title="Announcement page on Vector">我的网站</a>上找到。如果您需要源代码，请通过电子邮件与我联系。
</p>

<hr>

<h3>支持</h3>
<p>&nbsp
因为我不能经常联网，所以我可能每周检查一次邮件。请做好长时间等待后才能收到邮件回复的准备。这有一个<a href="http://www.livebusinesschat.com/smf/index.php?board=396.0" target="_blank" title="MultiPar forum on Live Business Chat">网络论坛</a>为MultiPar用户提供交流帮助。即便我无法回复您的问题，其他用户也可能帮到您。
</p>
<p>&nbsp
我的名字是Yutaka Sawada。电子邮件地址是“tenfon (at mark) outlook.jp”，用于PayPal的 “multipar (at mark) outlook.jp”和SourceForge用户的“tenfon (at mark) users.sourceforge.net”。因为它们使用的是相同的邮箱，所以请不要重复发送邮件。虽然原先电子邮件地址是“ten_fon (at mark) mail.goo.ne.jp”，但该邮箱邮件服务已于2014年3月停止，所以请不要发送到那里。(at mark) 是避免垃圾邮件的格式，请用“@”替换它。
</p>
<p>&nbsp
我此前收到过很多海外垃圾邮件。如果邮件被检测为垃圾邮件或可疑邮件，邮件服务器可能会自动将其删除，我将无法看到它。如果您一直没有收到回复，可以在网络论坛上向我询问。
</p>

<h3>链接</h3>
<p>&nbsp
我在<a href="http://hp.vector.co.jp/authors/VA021385/" target="_blank" title="Announcement page on Vector">个人主页</a><i>vector.co.jp</i>有介绍MultiPar。使用这个页面上的文件直链可能不太合适，这还有一个<a href="http://www.vector.co.jp/soft/dl/winnt/util/se460801.html" target="_blank" title="Download page on Vector">官方下载页面</a>。当您在某处输入一个链接时，请不要包含文件名。
</p>

</body>
</html>
