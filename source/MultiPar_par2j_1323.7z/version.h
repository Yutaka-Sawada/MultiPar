﻿#define CLIENT_VERSION	0x1323		// クライアントのバージョン番号
