﻿#define CLIENT_VERSION	0x1319		// クライアントのバージョン番号
