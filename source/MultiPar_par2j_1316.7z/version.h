﻿#define CLIENT_VERSION	0x1316		// クライアントのバージョン番号
