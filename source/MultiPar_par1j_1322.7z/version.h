﻿#define CLIENT_VERSION	0x1322		// クライアントのバージョン番号
