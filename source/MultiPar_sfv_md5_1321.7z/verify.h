﻿
// SFV ファイル
int verify_sfv(
	char *ascii_buf,
	wchar_t *file_path);

// MD5 ファイル
int verify_md5(
	char *ascii_buf,
	wchar_t *file_path);

