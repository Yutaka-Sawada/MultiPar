﻿#define CLIENT_VERSION	0x1321		// クライアントのバージョン番号
