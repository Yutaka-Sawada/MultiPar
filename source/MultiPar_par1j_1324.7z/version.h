﻿#define FILE_VERSION "1.3.2.4"	// ファイルのバージョン番号
#define PRODUCT_VERSION 0x132	// クライアントのバージョン番号
