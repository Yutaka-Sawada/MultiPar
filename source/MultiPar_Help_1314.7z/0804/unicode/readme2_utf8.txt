<html lang="zh">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<meta http-equiv="Content-Style-Type" content="text/css">
<style type="text/css">
<!--
*       {line-height:1.5;}
a       {text-decoration:none;}
a:hover {text-decoration:underline;}
-->
</style>
<title>导言 - 注意事项</title>
</head>
<body>

<h3>失败 故障 错误</h3>
<p>&nbsp
使用本程序产生的风险由您个人承担，因为我可能会遗漏一些东西。如果您发现程序运行状况有异，请向我反馈。一些重要的反馈信息，如输出日志、屏幕截图、文件名、文件大小、电脑规格和事件详情（何时/何地/发生什么/结果如何），将有助于解决问题。请尽可能在反馈时附带上它们。之后，我将在下一个版本中修复问题。
</p>

<h3>安全风险</h3>
<p>&nbsp
您应当将PAR文件与其源文件在安全级别上同等视之。当您在某些文件中有秘密数据并对其进行了加密时，需要对已加密的文件创建PAR文件。如果您对非加密文件创建PAR文件，其他人可能通过PAR文件知道原始机密数据的情况。即使没有足够的冗余来完全恢复源文件，它们的PAR文件也可能为间谍提供有用的信息。
</p>
<p>&nbsp
Parchive无法阻止恶意修改。使用未知的PAR文件进行恢复，就像在电脑上复制未知文件一样。恢复文件的可靠性取决于它们的PAR文件。当PAR文件被破解者恶意修改时，PAR客户端可能会将原始有效文件修改为无效文件。例如，如果有人修改了您的源文件并创建了PAR文件，这个PAR文件将会损坏您完整的源文件。
</p>

<h3>PAR 3.0规范尚未完成</h3>
<p>&nbsp
MultiPar中的PAR 3.0仅用于个人测试目的。由于我在编写提案时有时会修改其算法和格式，因此当前的PAR 3.0规范将与未来的规范不兼容。请不要将当前的PAR3文件发送给可能没有相同版本的其他人。
</p>
<p>&nbsp
目前样本PAR3尚未广泛应用，规范正在更新中。
</p>

</body>
</html>
