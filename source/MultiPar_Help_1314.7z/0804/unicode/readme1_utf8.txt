<html lang="zh">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<meta http-equiv="Content-Style-Type" content="text/css">
<style type="text/css">
<!--
*       {line-height:1.5;}
a       {text-decoration:none;}
a:hover {text-decoration:underline;}
-->
</style>
<title>导言 - 简介</title>
</head>
<body>

使用PAR恢复文件来恢复受损或丢失的文件。<br>
<font size=5>MultiPar</font>&nbsp（整合了PAR客户端与图形用户界面）
<hr>

<h3>介绍</h3>
<p>&nbsp
MultiPar是用来替代<a href="http://www.quickpar.org.uk/" target="_blank" title="http://www.quickpar.org.uk/">QuickPar</a>而开发的。它的图形用户界面（GUI）与QuickPar相似，并已得到后者原作者Peter Clements的授权许可。尽管它看起来像是一个多语言版的QuickPar，但它有一些优秀独特的功能：如，支持Unicode字符，支持目录树结构，修复速度更快，恢复文件体积更小，支持脚本批处理等。
</p>

<h3>功能</h3>
<p>&nbsp
MultiPar支持PAR1.0和PAR2.0规范。请访问“<a href="http://parchive.sourceforge.net/" target="_blank" title="http://parchive.sourceforge.net/">Parchive project</a>”查看Parchive有关详情。MultiPar使用UTF-8或UTF-16处理非ASCII字符的文件名。MultiPar和<a href="http://www.chuchusoft.com/par2_tbb/" target="_blank" title="http://www.chuchusoft.com/par2_tbb/">par2_tbb</a>可以处理子目录和UTF-8文件名，而QuickPar和其他PAR2客户端则无法处理。几乎所有的PAR2客户端都不支持UTF-16文件名和注释。请谨慎使用这些特殊功能。
</p>

<h3>系统要求</h3>
<p>&nbsp
MultiPar需要电脑安装Windows XP或更高的版本（Windows Vista, 7, 8, 10等）。
</p>

</body>
</html>
