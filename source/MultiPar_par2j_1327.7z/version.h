﻿#define FILE_VERSION "1.3.2.7"	// ファイルのバージョン番号
#define PRODUCT_VERSION "1.3.2"	// 製品のバージョン番号
