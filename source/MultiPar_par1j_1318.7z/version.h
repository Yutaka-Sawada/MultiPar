﻿#define CLIENT_VERSION	0x1318		// クライアントのバージョン番号
