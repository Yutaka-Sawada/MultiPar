﻿#define CLIENT_VERSION	0x1317		// クライアントのバージョン番号
